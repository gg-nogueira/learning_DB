-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--

SELECT A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], C.nomecurso
FROM tQuiNoite.ALUNO A 
	 RIGHT OUTER JOIN tQuiNoite.CURSO C 
	 ON A.codcurso=C.codcurso
WHERE (C.nomecurso) like 'CST%'
ORDER BY A.nomealuno