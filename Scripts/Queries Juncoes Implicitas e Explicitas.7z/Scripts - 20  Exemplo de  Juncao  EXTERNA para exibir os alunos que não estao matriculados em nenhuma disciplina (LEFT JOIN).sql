/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em An�lise e Desenvolviment�o de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gest�o da Tecnologia da Informa��o
			    BEL em Sistemas de Informa��o
			    BEL em Ci�ncia da Computa��o
    Disciplina: Banco de Dados
    Objetivo  : Jun��o externa entre as tabelas DISCIPLINA, BOLETIM e ALUNO, para exibir todos 
				as disciplinas onde n�o ha alunos matriculados.
    Data      : Primeiro Semestre 2023
--*/
SELECT A.ra, A.nomealuno,  D.nomedisciplina
FROM      tQuaNoite.DISCIPLINA AS D
LEFT JOIN tQuaNoite.BOLETIM    AS B ON D.coddisciplina = B.coddisciplina
LEFT JOIN tQuaNoite.ALUNO      AS A ON A.ra = B.ra
WHERE B.coddisciplina IS NULL;