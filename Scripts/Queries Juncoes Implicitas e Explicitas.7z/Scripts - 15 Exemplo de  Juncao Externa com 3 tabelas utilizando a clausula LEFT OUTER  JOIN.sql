-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em An�lise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--
/* 
Right Outer Join (Jun��o externa � direita).Esta opera��o � inversa � anterior e retorna sempre
todos os registros da tabela � direita (a segunda tabela mencionada na consulta), mesmo se n�o 
existir registro correspondente na tabela � esquerda. Nestes casos, o valor NULL � retornado 
quando n�o h� correspond�ncia.
*/
--
SELECT A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], D.nomedisciplina [Nome Disciplina] ,
	   B.notan1 [Nota Grupo N1], B.notan2 [Nota Grupo N2],
	  (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60) [M�dia do aluno]
FROM tQuiNoite.ALUNO A RIGHT OUTER JOIN tQuiNoite.BOLETIM B    ON A.ra=B.ra
			       RIGHT OUTER JOIN tQuiNoite.DISCIPLINA D ON B.coddisciplina=D.coddisciplina
WHERE (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60)>1
ORDER BY A.nomealuno