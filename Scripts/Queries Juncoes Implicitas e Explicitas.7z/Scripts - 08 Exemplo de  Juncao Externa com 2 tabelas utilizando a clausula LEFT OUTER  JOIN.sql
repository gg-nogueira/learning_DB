/* FMU - Faculdades Metropolitanas Unidas
Cursos		:CST em Análise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informação
			 BEL em Ciência da Computação
			 CST em BIG DATA
Objetivo	:Exemplificar aplicação de junção externa (OUTER JOIN) considerando 2 tabelas
             e o operador LIKE
Data		: Segundo Semestre 2021
*/
SELECT 	A.ra [Registro do Aluno], 
		A.nomealuno [Nome do Aluno], 
		C.nomecurso [Nome do Curso] 
FROM tQuiNoite.ALUNO A 
	 LEFT OUTER JOIN 
	 tQuiNoite.CURSO C 
	 ON A.codcurso=C.codcurso
WHERE (C.nomecurso) LIKE 'CST%'
ORDER BY A.nomealuno