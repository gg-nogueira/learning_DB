-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em An�lise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--

SELECT B.ra       	    [Registro do Aluno], 
	   B.coddisciplina 	[Codigo da Disciplina], 
       B.semestre 		[Semestre do Curso], 
	   B.notan1     	[Nota Grupo N1], 
	   B.notan2 		[Nota Grupo N2],
      (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60) [M�dia Semestral]
FROM tQuiNoite.BOLETIM B
WHERE (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60)>=5

GROUP BY B.ra,B.coddisciplina, B.semestre, B.notan1, B.notan2,
       (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60)
/*Uma cl�usula HAVING � como uma cl�usula WHERE, a diferen�a � que 
  ela se aplica somente a grupos como um todo (ou seja, as linhas do
  conjunto de resultados que representam grupos), enquanto a cl�usula
  WHERE se aplica a linhas individuais. Uma consulta pode conter uma
  cl�usula WHERE e uma cl�usula HAVING.
*/
-- HAVING AVG (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60)>=5