-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em An�lise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--

SELECT 	B.ra 				[Registro do Aluno], 
		A.nomealuno 		[Nome do Aluno],
		D.nomedisciplina 	[Nome da Disciplina], 
		B.semestre 			[Semestre do Curso], 
		B.notan1 			[Nota Av Continuada], 
		B.notan2 			[Nota Prova regimental], 
		(B.notan1*0.40 + (B.notan2*0.90 +notaaps)*0.60) [M�dia Semestral]
FROM tQuiNoite.ALUNO A, tQuiNoite.BOLETIM B, tQuiNoite.DISCIPLINA D
WHERE A.ra = B.ra AND B.coddisciplina = D.coddisciplina AND 
   (B.notan1*0.40 + (B.notan2*0.90 +notaaps)*0.60)>=
   (
     SELECT AVG((B.notan1*0.40 + (B.notan2*0.90 +notaaps)*0.60)) 
	 FROM tQuiNoite.BOLETIM B
	)

GROUP BY 	B.ra,A.nomealuno, D.nomedisciplina, B.coddisciplina, 
			B.semestre, B.notan1, B.notan2,(B.notan1*0.40 + (B.notan2*0.90 +notaaps)*0.60)
/*Uma cl�usula HAVING � como uma cl�usula WHERE, a diferen�a � que 
  ela se aplica somente a grupos como um todo (ou seja, as linhas do
  conjunto de resultados que representam grupos), enquanto a cl�usula
  WHERE se aplica a linhas individuais. Uma consulta pode conter uma
  cl�usula WHERE e uma cl�usula HAVING.
*/
-- HAVING AVG (B.notan1*0.40 + (B.notan2*0.90 +notaaps)*0.60)>=5