/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em An�lise e Desenvolviment�o de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gest�o da Tecnologia da Informa��o
			    BEL em Sistemas de Informa��o
			    BEL em Ci�ncia da Computa��o
    Disciplina: Banco de Dados
    Objetivo  : Jun��o externa entre as tabelas DISCIPLINA, BOLETIM e ALUNO, para exibir todos 
				as disciplinas onde n�o ha alunos matriculados.
    Data      : Primeiro Semestre 2023
------------------------------------------------------------------------------------------
    A cl�usula LEFT JOIN � usada para trazer todas as disciplinas, mesmo que elas 
	n�o tenham alunos matriculados. 
	A cl�usula DISTINCT � usada para retornar apenas resultados �nicos. 
	A cl�usula WHERE � usada para filtrar os resultados, exibindo apenas as disciplinas
	sem alunos matriculados.
----------------------------------------------------------------------------------------
*/
SELECT DISTINCT
A.ra 				[Registro do Aluno],
A.nomealuno 		[Nome do Aluno],
C.nomecurso 		[Nome do Curso],
D.nomedisciplina 	[Nome da Disciplina]
FROM
		  tQuaNoite.DISCIPLINA  AS D
LEFT JOIN tQuaNoite.MATRICULA 	AS M ON D.coddisciplina = M.coddisciplina
LEFT JOIN tQuaNoite.ALUNO 		AS A ON A.ra = M.ra
LEFT JOIN tQuaNoite.CURSO 		AS C ON D.codcurso = C.codcurso
WHERE     M.chavematricula IS NULL;