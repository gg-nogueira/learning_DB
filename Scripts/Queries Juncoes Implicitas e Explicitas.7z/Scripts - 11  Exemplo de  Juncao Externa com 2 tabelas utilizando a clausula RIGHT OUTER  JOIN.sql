-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar aplicação de junção externa (OUTER JOIN) considerando
--              : duas Tabelas

SELECT A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], C.nomecurso
FROM tQuiNoite.ALUNO A 
	 RIGTH OUTER JOIN tQuiNoite.CURSO C 
	 ON A.codcurso=C.codcurso
WHERE (C.nomecurso) LIKE 'CST%'
ORDER BY A.nomealuno