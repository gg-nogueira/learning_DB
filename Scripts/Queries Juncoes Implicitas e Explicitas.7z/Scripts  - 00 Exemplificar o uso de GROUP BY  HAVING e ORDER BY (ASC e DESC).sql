-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--              : Nesta exemplo estamos utilizando Alias de Coluna e Tabelas
--              : O banco de dados deve estar criado e aberto

SELECT 	A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], D.nomedisciplina, 
		B.notan1, B.notan2
FROM    tQuiNoite.ALUNO A, tQuiNoite.BOLETIM B, tQuiNoite.DISCIPLINA D
WHERE   A.ra=B.ra and B.coddisciplina=D.coddisciplina
--      ORDER BY C.nomecurso, A.nomealuno, A.ra
ORDER BY A.nomealuno