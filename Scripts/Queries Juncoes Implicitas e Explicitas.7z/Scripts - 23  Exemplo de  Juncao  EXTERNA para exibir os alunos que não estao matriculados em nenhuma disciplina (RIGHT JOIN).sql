/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em An�lise e Desenvolviment�o de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gest�o da Tecnologia da Informa��o
			    BEL em Sistemas de Informa��o
			    BEL em Ci�ncia da Computa��o
    Disciplina: Banco de Dados
    Objetivo  : Jun��o externa entre as tabelas DISCIPLINA, BOLETIM e ALUNO, para exibir todos 
				as disciplinas onde n�o ha alunos matriculados.
    Data      : Primeiro Semestre 2023
------------------------------------------------------------------------------------------
	Essa consulta usa um RIGHT JOIN para combinar as tabelas ALUNO, BOLETIM e DISCIPLINA 
	com base na condi��o BOLETIM.coddisciplina = DISCIPLINA.coddisciplina. 
	Isso resulta em uma tabela intermedi�ria que cont�m todas as linhas da tabela 
	DISCIPLINA, bem como as linhas correspondentes da tabela BOLETIM. 
	Se n�o houver uma correspond�ncia para uma linha da tabela DISCIPLINA, 
	a consulta retornar� valores NULL para todas as colunas da tabela BOLETIM.

	A cl�usula WHERE � ent�o aplicada � tabela intermedi�ria para filtrar as linhas 
	onde o valor de BOLETIM.coddisciplina � NULL. Isso significa que a consulta 
	retornar� apenas as disciplinas que n�o t�m alunos matriculados. 
	A coluna nomedisciplina � ent�o projetada a partir das linhas filtradas 
	para produzir o resultado final.
*/
SELECT 	A.ra 				[Registro do Aluno], 
		A.nomealuno 		[Nome do Aluno], 
		D.nomedisciplina 	[Nome da Disciplina]
FROM 		tQuaNoite.BOLETIM		AS B
RIGHT JOIN 	tQuaNoite.ALUNO 		AS A ON B.ra = A.ra
RIGHT JOIN 	tQuaNoite.DISCIPLINA	AS D ON B.coddisciplina = D.coddisciplina
WHERE B.coddisciplina IS NULL;