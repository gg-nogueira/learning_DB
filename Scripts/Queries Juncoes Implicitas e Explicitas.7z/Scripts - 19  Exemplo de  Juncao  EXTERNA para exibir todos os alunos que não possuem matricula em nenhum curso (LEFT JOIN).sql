/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em An�lise e Desenvolviment�o de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gest�o da Tecnologia da Informa��o
			    BEL em Sistemas de Informa��o
			    BEL em Ci�ncia da Computa��o
    Disciplina: Banco de Dados
    Objetivo  : Jun��o externa entre as tabelas ALUNO e CURSO, para exibir todos 
				os cursos que n�o est�o matriculados em nenhum CURSO.
    Data      : Primeiro Semestre 2023
--*/
SELECT A.ra, A.nomealuno, C.codcurso, C.nomecurso
FROM tQuaNoite.CURSO AS C
LEFT JOIN 
	 tQuaNoite.ALUNO AS A 
ON C.codcurso = A.codcurso
WHERE A.codcurso IS NULL;