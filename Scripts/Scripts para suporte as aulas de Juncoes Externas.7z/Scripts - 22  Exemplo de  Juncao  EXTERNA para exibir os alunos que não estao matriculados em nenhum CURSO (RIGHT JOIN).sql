/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em An�lise e Desenvolviment�o de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gest�o da Tecnologia da Informa��o
			    BEL em Sistemas de Informa��o
			    BEL em Ci�ncia da Computa��o
    Disciplina: Banco de Dados
    Objetivo  : Jun��o externa entre as tabelas ALUNO e CURSO, para exibir todos 
				os CURSOS onde n�o ha alunos matriculados.
    Data      : Primeiro Semestre 2023
------------------------------------------------------------------------------------------
Essa consulta usa um RIGHT JOIN para combinar as tabelas ALUNO e CURSO com base na 
condi��o ALUNO.codcurso = CURSO.codcurso. Isso resulta em uma tabela intermedi�ria 
que cont�m todas as linhas da tabela CURSO, bem como as linhas correspondentes da 
tabela ALUNO. Se n�o houver uma correspond�ncia para uma linha da tabela CURSO, 
a consulta retornar� valores NULL para todas as colunas da tabela ALUNO.

As colunas ra, nomealuno e nomecurso s�o ent�o projetadas a partir da tabela 
intermedi�ria para produzir o resultado final. 
Isso nos dar� uma lista de todos os cursos e seus respectivos alunos, 
incluindo cursos que n�o t�m alunos matriculados.
----------------------------------------------------------------------------------------
*/
USE BDFmuSegNoite;
GO
SELECT A.ra, A.nomealuno, C.nomecurso
FROM 	tSegNoite.ALUNO AS A
RIGHT JOIN 
		tSegNoite.CURSO AS C
		ON A.codcurso = C.codcurso;
--rodar novamente com a cl�usula WHERE habilitada
--WHERE ALUNO.ra IS NULL;