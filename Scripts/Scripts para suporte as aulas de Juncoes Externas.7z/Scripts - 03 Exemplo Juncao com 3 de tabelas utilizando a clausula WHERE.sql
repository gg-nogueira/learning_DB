-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em An�lise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--
/*                Neste exemplo, estamos demonstrando a constru��o de uma JUN��O NATURAL 
                  (Tetha e EQUI), sem a utiliza��o da Cl�usula JOIN, aplicando apenas a 
				  cl�usula WHERE
*/
USE BDFmuSegNoite;
GO
SELECT A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], D.nomedisciplina [Nome Disciplina] ,
       B.notan1 [Nota Grupo N1], B.notan2 [Nota Grupo N2],
	  (B.notan2*0.70+B.notan1*0.30) [M�dia do aluno]
FROM tSegNoite.ALUNO A, tSegNoite.BOLETIM B, tSegNoite.DISCIPLINA D
WHERE  A.ra=B.ra AND B.coddisciplina=D.coddisciplina AND 
      (B.notan1*0.40+(B.notan2*0.90+notaaps)*0.60)>1
ORDER BY A.nomealuno