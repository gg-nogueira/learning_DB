/* IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar aplicação de junção externa (OUTER JOIN) considerando
--              : duas Tabelas
                  Neste exemplos vamos identificar alunos que estão na base de dados mas,
				  não estão classificados em nenhuma das situações previstas pela IES.
				  Tabelas envolvidadas: ALUNO e MATRICULA
*/
USE BDFmuSegNoite;
GO
SELECT A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], 
       M.codcurso, M.serie, M.unidade, M.datamatricula, M.situacao
FROM tSegNoite.ALUNO A 
	 LEFT OUTER JOIN tSegNoite.MATRICULA M 
	 ON A.ra=M.ra
ORDER BY A.nomealuno