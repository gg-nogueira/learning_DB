/* FMU - Faculdades Metropolitanas Unidas
Cursos		:CST em Análise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informação
			 BEL em Ciência da Computação
			 CST em BIG DATA
Objetivo	:Exemplificar o uso de Junção Exlicita INTERNA utilizando 4 tabelas
Data		: Segundo Semestre 2021
*/
USE BDFmuSegNoite;
GO
SELECT 		A.ra 		[Registro do Aluno], 
			A.nomealuno [Nome do Aluno], 
			D.nomedisciplina, 
			B.notan1,
			B.notan2
FROM tSegNoite.ALUNO A 	INNER JOIN tSegNoite.BOLETIM B    ON  A.ra=B.ra
						INNER JOIN tSegNoite.DISCIPLINA D ON B.coddisciplina=D.coddisciplina
--
ORDER BY A.nomealuno