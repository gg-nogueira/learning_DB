-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em An�lise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--
/*
Full Outer Join (Jun��o externa total). Esta opera��o apresenta todos os dados das tabelas � 
esquerda e � direita, mesmo que n�o possuam correspond�ncia em outra tabela. A tabela combinada 
possuir� assim todos os registros de ambas as tabelas e apresentar� valores nulos para os 
registros sem correspond�ncia.
*/
USE BDFmuSegNoite;
GO
SELECT A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], C.nomecurso
FROM   tSegNoite.ALUNO A 
       FULL OUTER JOIN tSegNoite.CURSO C 
	   ON A.codcurso=C.codcurso
WHERE (C.nomecurso) LIKE 'CST%'
ORDER BY A.nomealuno