/* FMU - Faculdades Metropolitanas Unidas
Cursos		:CST em Análise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informação
			 BEL em Ciência da Computação
			 CST em BIG DATA
Objetivo	:Exemplificar o uso de Junção Exlicita INTERNA utilizando 3 tabelas
Data		: Segundo Semestre 2021
*/
USE BDFmuSegNoite;
GO
SELECT  A.ra 			 [Registro do Aluno], 
		A.nomealuno 	 [Nome do Aluno], 
		D.nomedisciplina [Nome da Disciplina], 
        B.notan1         [NomeGrupoN1], 
		B.notan2		 [NotaGrupoN2]
FROM tSegNoite.ALUNO A 	JOIN tSegNoite.BOLETIM B    ON A.ra=B.ra 
						JOIN tSegNoite.DISCIPLINA D ON B.coddisciplina=D.coddisciplina
ORDER BY A.nomealuno