/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em An�lise e Desenvolviment�o de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gest�o da Tecnologia da Informa��o
			    BEL em Sistemas de Informa��o
			    BEL em Ci�ncia da Computa��o
    Disciplina: Banco de Dados
    Objetivo  : Fazer a jun��o de 4 tabelas no SQL
    Data      : Primeiro Semestre 2023

    CRIA��O DO DATABASE SE ELE N�O EXISTIR
--*/
USE BDFmuSegNoite;
GO
SELECT A.ra, A.nomealuno, C.nomecurso, D.nomedisciplina, B.notaaps
FROM tSegNoite.ALUNO A
INNER JOIN tSegNoite.BOLETIM B		ON A.ra = B.ra
INNER JOIN tSegNoite.DISCIPLINA D	ON B.coddisciplina = D.coddisciplina
INNER JOIN tSegNoite.CURSO C		ON A.codcurso = C.codcurso
WHERE C.codcurso = 121;
/* Vejam a sequencia de execu��o desta query.
	1) A primeira linha a ser executada � a 14. Nesta � feita a JUN��O entre as tabelas
       ALUNO e BOLETIM atrav�s da PK e FK destas tabelas. Desta opera��o gera��o uma
	   tabela INTERMEDIARIA.
	2) O proximo passo � realizar a JUN��O desta tabela INTERMEDIARIA com a tabela DISCIPLINA
	   atrav�s da PK e FK destas tabelas.Desta opera��o gera��o uma segunda tabela INTERMEDIARIA.
	3) Na sequ�ncia realiza-se a �ltima JUN��O entre a segunda tabela INTERMEDIARIA com a tabela
	   CURSO.
	4) Continuando, a linha 19 (Cl�usula WHERE) e aplicada, finalizando a execu��o da query
*/