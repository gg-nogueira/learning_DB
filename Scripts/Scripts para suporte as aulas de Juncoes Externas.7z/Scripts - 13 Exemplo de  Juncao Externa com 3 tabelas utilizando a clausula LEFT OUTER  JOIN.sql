-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em An�lise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar o uso de GROUP BY / HAVING e ORDER BY (ASC e DESC)
--
--				: Exemplificar a aplica��o de Jun��es externas 
/* 				Left Outer Join (Jun��o externa � esquerda).   O resultado desta sele��o sempre cont�m todos os registros da tabela esquerda 
				(isto �, a primeira tabela mencionada na consulta), mesmo quando n�o exista registros correspondentes na tabela direita. 
				Desta forma, esta sele��o retorna todos os valores da tabela esquerda com os valores da tabela direita correspondente, ou 
				quando n�o h� correspond�ncia retorna um valor NULL. */
--
USE BDFmuSegNoite;
GO
SELECT A.ra [Registro do Aluno], A.nomealuno [Nome do Aluno], D.nomedisciplina [Nome Disciplina] ,
	   B.notan1 [Nota Grupo N1], B.notan2 [Nota Grupo N2],
	  (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60) [M�dia do aluno]
FROM tSegNoite.ALUNO A 	LEFT OUTER JOIN tSegNoite.BOLETIM    B ON A.ra=B.ra
						LEFT OUTER JOIN tSegNoite.DISCIPLINA D ON B.coddisciplina=D.coddisciplina
WHERE (B.notan1*0.40+(B.notan2*0.90+notaaps)*0,60)>1
ORDER BY A.nomealuno