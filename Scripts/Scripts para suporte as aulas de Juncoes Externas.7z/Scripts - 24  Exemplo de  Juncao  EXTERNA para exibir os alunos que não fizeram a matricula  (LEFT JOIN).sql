/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em An�lise e Desenvolviment�o de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gest�o da Tecnologia da Informa��o
			    BEL em Sistemas de Informa��o
			    BEL em Ci�ncia da Computa��o
    Disciplina: Banco de Dados
    Objetivo  : Jun��o externa entre as tabelas DISCIPLINA, BOLETIM e ALUNO, para exibir todos 
				as disciplinas onde n�o ha alunos matriculados.
    Data      : Primeiro Semestre 2023
------------------------------------------------------------------------------------------
Explicando a query:

	Nas linhas 25 a 31 primeira linha define as colunas que queremos visualizar, que s�o o ra do aluno,		A.nomealuno, 
	M.codmatricula, M.codcurso, M.serie,M.unidade, M.datamatricula, M.situacao (quando existir).
	Na linha 32, definimos a tabela da qual queremos buscar os dados, que � a 
	tabela ALUNO.
	Na linha 33 � a jun��o externa LEFT JOIN, que relaciona a tabela ALUNO com 
	a tabela MATRICULA usando o RA do aluno como chave de liga��o.
	Na linha 34 � uma condi��o que especifica que queremos apenas as linhas em que 
	o ra da tabela MATRICULA � NULL, ou seja, em que o aluno n�o est� matriculado.
	Com essa query, ser� poss�vel identificar quais alunos n�o est�o matriculados no curso.	
*/
USE BDFmuSegNoite;
GO
SELECT 	A.ra, 
		A.nomealuno, 
		M.codmatricula, 
		M.codcurso, M.serie, 
		M.unidade, 
		M.datamatricula, 
		M.situacao
FROM tSegNoite.ALUNO AS A
LEFT JOIN tSegNoite.MATRICULA AS M ON A.ra = M.ra
WHERE M.ra IS NULL;