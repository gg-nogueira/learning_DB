/* FMU - Faculdades Metropolitanas Unidas
Cursos		:CST em An�lise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informa��o
			 BEL em Ci�ncia da Computa��o
			 CST em BIG DATA
Objetivo	:Exemplificar o uso de Jun��o Exlicita INTERNA utilizando 4 tabelas
Data		: Segundo Semestre 2021
*/
USE BDFmuSegNoite;
GO
SELECT 	A.ra 												[Registro do Aluno], 
		A.nomealuno 										[Nome do Aluno], 
		C.nomecurso 										[Nome do Curso], 
		D.nomedisciplina 									[Nome Disciplina],
	    B.notan1 											[Nota Grupo N1], 
		B.notan2 											[Nota Grupo N2],
	   (B.notan1*0.40+(B.notan2*0.90+B.notaaps*0.10)*0.60) 	[M�dia do aluno]
FROM tSegNoite.ALUNO A	INNER JOIN tSegNoite.CURSO      C ON A.codcurso = C.codcurso
						INNER JOIN tSegNoite.BOLETIM    B ON A.ra=B.ra
						INNER JOIN tSegNoite.DISCIPLINA D ON B.coddisciplina=D.coddisciplina
WHERE (B.notan1*0.40+(B.notan2*0.90+B.notaaps*0.10)*0.60)> 1
ORDER BY A.nomealuno