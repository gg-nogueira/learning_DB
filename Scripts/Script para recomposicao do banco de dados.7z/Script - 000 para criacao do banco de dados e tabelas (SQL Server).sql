/* FMU - Faculdades Metropolitanas Unidas
   Cursãos	:CST em Análise e Desenvolvimentão de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informação
			 BEL em Ciência da Computação
			 CST em BIG DATA
    Disciplina: Banco de Dados
    Objetivo  : Criar o Banco de Dados e Tabelas para suporte ao curso de SQL
    Data: Segundo Semestre 2022
	      Revisado em Outubro/2022
	Requisitos para rodar este Script
	*
	1. Habilite o modo full-text na sua instancia do SQL Server
    *
    2. Copie e cole este Script na janela de consulta do SQL Server Management Studio e;
	*
	Habilite o modo SQLCMD no menu de consulta 
	*
    3. Configure as seguintes variáveis de ambiente para 
	   a)o caminho / local dos arquivos com os dados de origem (csv)
	   b)o nome do banco de dados destino
	   c)o nome do schema
===============================================================================================
Obs:
	Caso não saiba como habilitar o full-text e o SQLCMD, acesse no 
	Ambiente de Aprendizagem (Moodle) o documento:
	"Orientações para rodar o "Script - 000 para criacao e população 
	 do banco de dados e tabelas (SQL Server)"
================================================================================================		 
--*/

:setvar SqlSamplesSourceDataPath "C:\BDFmuQuiManha\"
:setvar DatabaseName "BDFmuQuiManha"
:setvar SchemaName   "tQuiManha"
:setvar LangDefault  "us_english"
/* A Linha 41 contem uma configuração para o formado da data.Estas instruções fazem parte
   do TRANSACT SQL.
   Por padrão (Default) o SQL Server define as datas no formato yyyy-mm-dd, considerando que
   na nossa base de dados as datas estão no padrão dd-mm-yy, precisamos utilisar a configuração
   da linha 41. Mais informações sobre combinações de formato, acessa as páginas do SQL Server
*/
IF EXISTS
/* Esta função verifica se a linguagem default do SQL Server
   é us_english. Em caso positivo, a linha 54 é executada, 
   caso contrário o bloco definido nas linhas 53 a 55 será
   ignorado.
*/
   (	 
     SELECT [name]
	 FROM   [sys].[syslanguages]
     WHERE  [name] = N'$(LangDefault)'
	) 
	BEGIN
	-- Altera o padrão de exibição de datas.
		SET DATEFORMAT dmy;
	END
GO

--CRIAÇÃO DO DATABASE SE ELE NÃO EXISTIR	
IF EXISTS
   (
--	Esta parte do Script verifica nos objetos do dicionário de dados que
--	se encontram no master.dbo chamado de sysdatabases se existe
-- 	Banco de Dados com o nome definido da cláusula WHERE
-- 	Se sim ele executa as instruções logo abaixo da instrução CREATE DATABASE.
	 SELECT [name]
	 FROM [master].[sys].[databases]
     WHERE [name] = N'$(DatabaseName)'
    )
	BEGIN
		USE master;
		DROP DATABASE $(DatabaseName)
	END
CREATE DATABASE $(DatabaseName)
GO
-- Slides 90 a 92
-- CRIAÇÃO DO SCHEMA
-- Dar foco para o DATABASE que queremos criar o SCHEMA
USE $(DatabaseName);
-- O comando GO é usado para agrupar comandos SQL em lotes que são enviados jáuntos ao servidor
GO
--
-- Inicio do próximo lote de comandos
-- Slides 93 a 116
IF NOT EXISTS
	(
--	Esta parte do Script verifica nos objetos do dicionário de dados que
--	se encontram não sys.schemas se existe o SCHEMA com o nome definido da cláusula WHERE
-- 	Se sim ele executa as instruções logo abaixo da instrução CREATE SCHEMA.
	  SELECT SCHEMA_ID
	  FROM sys.schemas
	  WHERE [name] = N'$(SchemaName)'
	)
EXEC('CREATE SCHEMA $(SchemaName)')
GO
USE $(DatabaseName);
GO
--
-- Inicio do próximo lote de comandos para criação de TABELAS
--
/* O lote de instruções linhas 108 a 116 são opcionais.
   Este lote de comando que tem inicio na linha 108, começa testando se
   se a TABELA que queremos criar EXISTE.
   Se a função OBJECT_ID retornar NULL, significa que a TABELA não EXISTE,
   caso contrário a tabela já existe e então precisamos excluí-la antes de
   recriá-la
   prefixo N é utilizando quando os parâmetros são do tipo nvarchar, nchar ou ntext. 
   Estes tipos de dados utilizam um conjunto de caracteres UNICODE UCS-2 que são utilizados 
   quando há alguns idiomas que possuem caracteres especiais no alfabeto, 
   como por exemplo: portugues,polônes, japonês, dentre outros
*/
IF OBJECT_ID(N'$(SchemaName).CURSO','U') IS NOT NULL
/* 	OBJECT_ID é uma função do T-SQL que identifica se objetos de dados
-- 	como tabela, views, indices existe. onde:
	'U' é um object type que faz referencia a uma TABELA,
  	'V' é um object type que faz referencia a uma View,ele
	'P' é um object type que faz referencia a "store procedure", etc..
*/
	DROP TABLE $(SchemaName).CURSO;
	GO
--
-- Criação da tabela N'$(SchemaName)'.CURSO
--
CREATE TABLE $(SchemaName).CURSO
(
	[codcurso] 			[int] 			NOT NULL,
	[siglacurso] 		[varchar](10) 	NOT NULL,
	[nomecurso] 		[varchar](60) 	NOT NULL,
	[integralizacao] 	[smallint] 		NOT NULL,
	[autorizacao] 		[date] 			NOT NULL,
	[reconhecimento] 	[date] 			NULL,
	[notarec] 			[smallint] 		NOT NULL,
	/* Definição da Chave Primária (PK) da tabela curso	*/
	CONSTRAINT PK_CURSO_codcurso PRIMARY KEY (codcurso)
);
GO
/* é necessário aqui uma observação sobre a definição da chave primária
   Na frase: CONSTRAINT PK_CURSO_codcurso PRIMARY KEY (codcurso)
             CONSTRAINT é o comando para definição de uma chave primária (PK) ou
			            chave estrangeira (FK)
			 PK_CURSO_codcurso é o nome da chave primária. é um mnemônico que
			 facilita a identificação da chave, vez que
			 PK refere-se ao tipo de caso, neste caso chave primária
			 CURSO refere-se a qual tabela pertence a chave primária
			 codcurso é a coluna selecionada para receber este status, isto é,
			 chave primária.
			 PRIMARY KEY é a definição da chave
*/	
--
--Criacao da tabela VALORCURSO
--
CREATE TABLE $(SchemaName).VALORCURSO
(
	codcurso	int				not null,
	semletivo	smallint 		not null,
	ano			smallint 		not null,
	valor		decimal(8,2)	not null,
	majoracao	DATE 			not null
	/* Definição da Chave Primária (PK) da tabela curso	*/
	CONSTRAINT PK_VALORCURSO_codcurso PRIMARY KEY (codcurso)
);
GO	
--
--Criacao da tabela BOLSA
--
CREATE TABLE $(SchemaName).BOLSA
(
	codbolsa	int				not null,
	tipobolsa	varchar(10)		not null,
	desconto	decimal(3,2)	not null
	/* Definição da Chave Primária (PK) da tabela curso	*/
	CONSTRAINT PK_BOLSA_codbolsa PRIMARY KEY (codbolsa)
);
GO
--
--Criacao da tabela DEPARTAMENTO
--
CREATE TABLE $(SchemaName).DEPARTAMENTO
(
	[coddepto] 			[int] 			NOT NULL,
	[nomedepto] 		[varchar](50) 	NOT NULL,
	[codfaculdade] 		[int] 			NOT NULL,
	[codcoordenador] 	[int] 			NOT NULL,
	CONSTRAINT PK_DEPARTAMENTO_coddepto PRIMARY KEY (coddepto)
);


--
-- Criação da tabela PROFESSOR
--
CREATE TABLE $(SchemaName).PROFESSOR
(
	[codprofessor] 	[int] 			NOT NULL,
	[nomeprof] 		[varchar](70) 	NOT NULL,
	[titulacao] 	[varchar](12) 	NOT NULL,
	[coddepto] 		[int] 			NOT NULL,
	CONSTRAINT PK_PROFESSOR_codprofessor 	PRIMARY KEY (codprofessor),
	CONSTRAINT FK_PROFESSOR_coddepto 		FOREIGN KEY (coddepto) REFERENCES $(SchemaName).DEPARTAMENTO (coddepto),
);
--
-- Criacao da tabela DISCIPLINA
--
CREATE TABLE $(SchemaName).DISCIPLINA
(
	[coddisciplina] 	[int] 			NOT NULL,
	[chavedisciplina] 	[varchar](17) 	NOT NULL,
	[codcurso] 			[int] 			NOT NULL,
	[coddepto] 			[int] 			NOT NULL,
	[nomedisciplina] 	[varchar](74) 	NOT NULL,
	[seriecurso] 		[smallint] 		NOT NULL,
	CONSTRAINT PK_DISCIPLINA_coddisciplina 	PRIMARY KEY (coddisciplina),
	CONSTRAINT FK_DISCIPLINA_codcurso 		FOREIGN KEY (codcurso) REFERENCES $(SchemaName).CURSO(codcurso),
	CONSTRAINT FK_DISCIPLINA_coddepto 		FOREIGN KEY (coddepto) REFERENCES $(SchemaName).DEPARTAMENTO(coddepto)
);

--
--Criação da tabela MATRICULA
--
CREATE TABLE $(SchemaName).MATRICULA
(
	[chavematricula] 	[char](15) 		NOT NULL,
	[codmatricula] 		[char](11) 		NOT NULL,
	[ra] 				[int] 			NOT NULL,
	[codcurso] 			[int] 			NOT NULL,
	[serie] 			[smallint] 		NOT NULL,
	[codturno] 			[smallint] 		NOT NULL,
	[codunidade] 		[smallint] 		NOT NULL,
	[unidade] 			[varchar](10) 	NOT NULL,
	[codturma] 			[char](7) 		NOT NULL,
	[siglaturno] 		[char](2) 		NOT NULL,
	[tipocurso] 		[varchar](12) 	NOT NULL,
	[datamatricula] 	[date] 			NOT NULL,
	[coddisciplina] 	[int] 			NOT NULL,
	[sigladisciplina] 	[varchar](17) 	NOT NULL,
	[situacao] 			[varchar](11) 	NOT NULL,
	CONSTRAINT PK_MATRICULA_chavematricula 	PRIMARY KEY (chavematricula),
	CONSTRAINT FK_MATRICULA_codcurso		FOREIGN KEY (codcurso) 		REFERENCES $(SchemaName).CURSO (codcurso),
	CONSTRAINT FK_MATRICULA_coddisciplina	FOREIGN KEY (coddisciplina) REFERENCES $(SchemaName).DISCIPLINA (coddisciplina)
);
--
-- Criação da tabela GENERO
--
CREATE TABLE $(SchemaName).GENERO
(	
	[codgenero] 	[smallint] 		NOT NULL,
	[genero] 		[varchar](70) 	NOT NULL,
	[descricao] 	[varchar](200) 	NOT NULL,
	CONSTRAINT PK_GENERO_codgenero PRIMARY KEY (codgenero)	
);
--
-- Criação da tabela ESTADOCIVIL
--
CREATE TABLE $(SchemaName).ESTADOCIVIL
(	
	[codecivil] 	[smallint] 		NOT NULL,
	[estadocivil] 	[varchar](12) 	NOT NULL,
	CONSTRAINT PK_GENERO_codecivil PRIMARY KEY (codecivil)
);
--
--Criação da tabela ALUNO
--
CREATE TABLE $(SchemaName).ALUNO
(
	[ra] [int] NOT NULL,
	[nomealuno] 	[varchar](100) 	NOT NULL,
	[codcurso] 		[int] 			NOT NULL,
	[codgenero] 	[smallint] 		NOT NULL,
	[estadocivil] 	[char](5) 		NOT NULL,
	[datnasc] 		[date] 			NOT NULL,
	[logradouro] 	[varchar](16) 	NULL,
	[endereco] 		[varchar](100) 	NULL,
	[numero] 		[smallint] 		NULL,
	[complemento] 	[varchar](100) 	NULL,
	[bairro] 		[varchar](60) 	NULL,
	[cidade] 		[varchar](40) 	NULL,
	[uf] 			[varchar](3) 	NULL,
	[regiao] 		[varchar](16) 	NULL,
	[pais] 			[char](2) 		NULL,
	[cep] 			[char](8) 		NULL,
	[email] 		[varchar](60) 	NULL,
	[telefone] 		[varchar](20) 	NULL,
	[situacao] 		[varchar](11) 	NOT NULL,
	CONSTRAINT PK_ALUNO_ra       	PRIMARY KEY (ra),
	CONSTRAINT FK_ALUNO_codcurso 	FOREIGN KEY (codcurso) REFERENCES $(SchemaName).CURSO  (codcurso),
	CONSTRAINT FK_ALUNO_codgenero	FOREIGN KEY (codgenero)REFERENCES $(SchemaName).GENERO (codgenero)	
);
/* é necessário aqui uma observação sobre a definição da chave estrangeira
   Na frase: CONSTRAINT FK_ALUNO_codcurso FOREIGN KEY(codcurso) REFERENCES $(SchemaName).CURSO(codcurso)
             CONSTRAINT é o comando para definição de uma chave primária (PK) ou
			            chave estrangeira (FK)
			 FK_ALUNO_codcurso é o nome da chave primária. é um mnemônico que
			 facilita a identificação da chave, vez que
			 FK refere-se ao tipo de caso, neste caso chave estrangeira
			 ALUNO refere-se a qual tabela pertence a chave estrangeira
			 codcurso é a coluna selecionada para receber este status, isto é,
			 chave estrangeira.
			 FOREIGN KEY é a definição da chave estrangeira
			 REFERENCES é o parâmetro para estabelecer a relação / assãociação entre
			 as tabelas: ALUNO e CURSO
*/			
--
-- Criação da tabela BOLSISTA
--
CREATE TABLE $(SchemaName).BOLSISTA
(
	ra       	int 			not null,
	codcurso  	int 			not null,
	codbolsa   	int 		    not null
	CONSTRAINT PK_BOLSISTA_ra       PRIMARY KEY (ra),
	CONSTRAINT FK_BOLSISTA_codcurso FOREIGN KEY (codcurso)  REFERENCES $(SchemaName).CURSO (codcurso),
	CONSTRAINT FK_BOLSISTA_codbolsa	FOREIGN KEY (codbolsa)	REFERENCES $(SchemaName).BOLSA (codbolsa)	
);
--
-- Criação da tabela BOLETIM
--
CREATE TABLE $(SchemaName).BOLETIM
(
	[chavematricula] 	[char](15) 		NOT NULL,
	[codmatricula] 		[char](11) 		NOT NULL,
	[ra] 				[int] 			NOT NULL,
	[codcurso] 			[int] 			NOT NULL,
	[serie] 			[smallint] 		NOT NULL,
	[coddisciplina] 	[int] 			NOT NULL,
	[sigladisciplina] 	[varchar](17) 	NOT NULL,
	[notan1] 			[decimal](5, 2) NULL,
	[notan2] 			[decimal](5, 2) NULL,
	[notaaps] 			[decimal](5, 2) NULL,
	CONSTRAINT PK_BOLETIM_codmatricula	 	PRIMARY KEY (codmatricula),
	CONSTRAINT FK_BOLETIM_codcurso 			FOREIGN KEY (codcurso)      REFERENCES $(SchemaName).CURSO (codcurso),
	CONSTRAINT FK_BOLETIM_coddisciplina     FOREIGN KEY (coddisciplina) REFERENCES $(SchemaName).DISCIPLINA (coddisciplina)
);
/* Mudar o status de PRIMARY KEY da coluna codmatricula  */
ALTER TABLE $(SchemaName).BOLETIM DROP CONSTRAINT  PK_BOLETIM_codmatricula;
--            Recriar a variável considerando a nova chave primária que agora é chavematricula
ALTER TABLE $(SchemaName).BOLETIM ADD  CONSTRAINT  PK_BOLETIM_chavematricula PRIMARY KEY (chavematricula);
--
--Criação da tabela GRADE
--

CREATE TABLE $(SchemaName).[GRADE]
(
	[codmatricula] 		[char](11) 		NOT NULL,
	[chavematricula] 	[char](15) 		NOT NULL,
	[unidade] 			[varchar](10) 	NOT NULL,
	[codcoordenador] 	[int] 			NOT NULL,
	[siglacurso] 		[char](6) 		NOT NULL,
	[codcurso] 			[int] 			NOT NULL,
	[serie] 			[smallint] 		NOT NULL,
	[coddisciplina] 	[int] 			NOT NULL,
	[anoagenda] 		[int] 			NOT NULL,
	[semletivo] 		[smallint] 		NOT NULL,
	[sigladisciplina] 	[varchar](18) 	NOT NULL,
	[codturma] 			[char](7) 		NOT NULL,
	[siglaturno] 		[char](2) 		NOT NULL,
	[horario] 			[char](12) 		NOT NULL,
	[diasemana] 		[varchar](13) 	NOT NULL,
	[codprofessor] 		[int] 			NOT NULL,
	[titulacao] 		[varchar](15) 	NOT NULL,
	CONSTRAINT PK_GRADE_chavematricula 	PRIMARY KEY (chavematricula),
	CONSTRAINT FK_GRADE_codcoordenador 	FOREIGN KEY (codcoordenador) REFERENCES $(SchemaName).PROFESSOR  (codprofessor),
	CONSTRAINT FK_GRADE_coddisciplina 	FOREIGN KEY (coddisciplina)  REFERENCES $(SchemaName).DISCIPLINA (coddisciplina),
	CONSTRAINT FK_GRADE_codprofessor 	FOREIGN KEY (codprofessor)   REFERENCES $(SchemaName).PROFESSOR (codprofessor)
);
/*
===============================================================================================
População da tabela CURSO
Todas as tabelas serão populadas utilizando o recurso BULK INSERT
que permite a inserção de blocos de mais de 1000 linhas nas tabelas
===============================================================================================
*/
PRINT 'Loading [$(SchemaName)].[CURSO]';
--
BULK INSERT $(SchemaName).[CURSO]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)CURSO.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/* Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-SECOND
    omitir esta linha
*/
 FIRSTROW		=2,
  -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)matriERROS.txt'
);
GO
/*
===============================================================================================
População da tabela GENERO
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[GENERO]';
--
BULK INSERT $(SchemaName).[GENERO]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)GENERO.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-SECOND
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)genERROS.txt'
);
GO
/*
===============================================================================================
População da tabela ESTADO CIVIL
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[ESTADO CIVIL]';
BULK INSERT $(SchemaName).[ESTADOCIVIL]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)ESTADOCIVIL.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-SECOND
  -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)estcivERROS.txt'
);
GO
/*
===============================================================================================
População da tabela DEPARTAMENTO
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[DEPARTAMENTO]';
BULK INSERT $(SchemaName).[DEPARTAMENTO]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)DEPARTAMENTO.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-SECOND
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)deptERROS.txt'
);
GO
/*
===============================================================================================
População da tabela PROFESSOR
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[PROFESSOR]';
BULK INSERT $(SchemaName).[PROFESSOR]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)PROFESSOR.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)profERROS.txt'
);
GO
/*
===============================================================================================
População da tabela DISCIPLINA
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[DISCIPLINA]';
BULK INSERT $(SchemaName).[DISCIPLINA]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)DISCIPLINA.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-SECOND
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)disciERROS.txt'
);
GO
/*
===============================================================================================
População da tabela MATRICULA
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[MATRICULA]';
BULK INSERT $(SchemaName).[MATRICULA]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)MATRICULA.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se 
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)matriERROS.txt'
);
GO
/*
===============================================================================================
População da tabela ALUNO
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[ALUNO]';
BULK INSERT $(SchemaName).[ALUNO]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)ALUNO.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se 
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)aluERROS.txt'
);
GO
/*
===============================================================================================
População da tabela BOLETIM
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[BOLETIM]';
BULK INSERT $(SchemaName).[BOLETIM]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)BOLETIM.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se 
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)gradERROS.txt'
);
GO
/*
===============================================================================================
População da tabela GRADE
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[GRADE]';
BULK INSERT $(SchemaName).[GRADE]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)GRADE.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se 
 -- omitir esta linha
*/ 
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)gradERROS.txt'
);
GO
/*
===============================================================================================
População da tabela BOLSA
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[BOLSA]';
BULK INSERT $(SchemaName).[BOLSA]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)BOLSA.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se 
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)gradERROS.txt'
);
GO
/*
===============================================================================================
População da tabela BOLSISTA
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[BOLSISTA]';
BULK INSERT $(SchemaName).[BOLSISTA]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)BOLSISTA.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
 /*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se 
 -- omitir esta linha
 */
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)gradERROS.txt'
);
GO
/*
===============================================================================================
População da tabela VALORCURSO
===============================================================================================
*/
PRINT 'Loading $(SchemaName).[VALORCURSO]';
BULK INSERT $(SchemaName).[VALORCURSO]
-- Define-se o caminho e nome do arquivo origem.
FROM '$(SqlSamplesSourceDataPath)VALORCURSO.csv'
WITH
(
 FORMAT = 'CSV',
 DATAFILETYPE	='char',
/*-- Se o arquivo CSV tiver cabeçalho, declara-se a FIRSTROW = 2, caso contrario pode-se 
 -- omitir esta linha
*/
 FIRSTROW		=2,
 -- como o arquivo de origem contém sinais gráficos da nossa lingua, o ideal e utilizar 
 -- códigos UNICODE
 CODEPAGE = '65001',
 -- Entenda-se FIELDTERMINATOR como o caractere separador de campos / colunas
 FIELDTERMINATOR = ';',
 -- Terminador de final de linha, normalmente é \r\n  que em hexadecimal é representado por
 --  0x0a
 ROWTERMINATOR	='0x0a',
 -- Define-se MAXERRORS com um valor alto que é para o BULK INSERT reportar o erro, MASTER
 -- continuar o processo de importação.
 MAXERRORS = 200000,
 -- Definição do caminho e nome do arquivo de erros.
 ERRORFILE='$(SqlSamplesSourceDataPath)gradERROS.txt'
);
GO
/*
===================================================================================================
Fim do Script
===================================================================================================
*/