/* FMU - Faculdades Metropolitanas Unidas
   Cursos	     	: CST em Análise e Desenvolvimento de Sistemas
					  CST em Sistemas para Internet
			          BEL em Sistemas de Informação
			          BEL em Ciência da Computação
			          CST em BIG DATA
    Disciplina   	: Banco de Dados
    Objetivo	 	: CRIAR Views através de uma view já existente.
                      Neste script veremos a sintaxe geral para criar Views
				      no Banco de Dados, utilizando subqueries.
					  uma view é uma representação virtual de uma ou mais tabelas que permite 
					  aos usuários executar consultas complexas em um conjunto de dados 
					  simplificado. 
					  Basicamente, uma view é uma consulta armazenada que é executada 
					  sempre que a view é acessada.
					  Quando criada uma view é armazenada no catálogo / dicionário de dados
    Data			: Primeiro Semestre 2023
----------------------------------------------------------------------------------------------  
                                        Sintaxe padrão
----------------------------------------------------------------------------------------------	
--*/
-- Selecionar / Dar foco no banco destino
USE [BDFmuSegNoite]
GO
-- Criação da view
-- para diferenciar de outros objetos de dados, via de regra, utiliza-se o prefixo vw
CREATE VIEW	tQuiManha.[Historico Segundo Semestre]
-- Selecionando as colunas e respectivos valores que farão parte da view
-- Percebe que neste script, estamos utilizando ALIAS de coluna
AS SELECT 	H.[Registro do Aluno], 
			H.[Nome do aluno], 
			H.[Nome da Disciplina], 
			H.[Média Final]
FROM 		tQuiManha.vwHISTORICO AS H
WHERE 		H.[Média Final]>=7.0