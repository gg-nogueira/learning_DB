/* FMU - Faculdades Metropolitanas Unidas
   Cursos	     : CST em Análise e Desenvolvimento de Sistemas
                   CST em Sistemas para Internet
			       BEL em Sistemas de Informação
			       BEL em Ciência da Computação
			       CST em BIG DATA
    Disciplina   : Banco de Dados
    Objetivo	 : Exercitar instruções DML para DELETAR linhas (tuplas) de uma tabela do
	               banco de dados utilizando subqueries com operador IN da teoria dos 
				   conjuntos.
    Data         : Primeiro Semestre 2023
-----------------------------------------------------------------------------------------------
                                            Sintaxe Padrão
-----------------------------------------------------------------------------------------------	
1) Selecionar o banco de dados
USE [BDFmuSegNoite]
GO
2) Aplicar a instrução DELETE
DELETE FROM [Nome do schema].[Nome da tabela]
3) Inserir as retrições
WHERE [restrições] -- É importante declarar as restrições, sob pena do SQL Server
                      excluir todas as linhas (tuplas) do schema e tabela definidos
GO
--*/
USE [BDFmuSegNoite]
GO
DELETE FROM [tQuiManha].[ALUNO]
WHERE ra IN (
			    SELECT   ra
				FROM     tQuiManha.ALUNO
				WHERE    codcurso='123'
			);
GO