/* FMU - Faculdades Metropolitanas Unidas
   Cursos	     	: CST em Análise e Desenvolvimento de Sistemas
					  CST em Sistemas para Internet
			          BEL em Sistemas de Informação
			          BEL em Ciência da Computação
			          CST em BIG DATA
    Disciplina   	: Banco de Dados
    Objetivo	 	: CRIAR Views.
                      Neste script veremos a sintaxe geral para criar Views
				      no Banco de Dados, utilizando subqueries.
					  uma view é uma representação virtual de uma ou mais tabelas que permite 
					  aos usuários executar consultas complexas em um conjunto de dados 
					  simplificado. 
					  Basicamente, uma view é uma consulta armazenada que é executada 
					  sempre que a view é acessada.
					  Quando criada uma view é armazenada no catálogo / dicionário de dados
    Data			: Primeiro Semestre 2023
----------------------------------------------------------------------------------------------  
                                        Sintaxe padrão
----------------------------------------------------------------------------------------------	
--*/
-- Selecionar / Dar foco no banco destino
USE [BDFmuSegNoite]
-- Criação da view
-- para diferenciar de outros objetos de dados, via de regra, utiliza-se o prefixo vw
CREATE VIEW	tQuiManha.vwHISTORICO
-- Selecionando as colunas e respectivos valores que farão parte da view
-- Percebe que neste script, estamos utilizando ALIAS de coluna
AS	SELECT	A.ra 				AS [Registro do Aluno], 
			A.nomealuno 		AS [Nome do Aluno], 
			D.nomedisciplina 	AS [Nome da Disciplina], 
			(0.40*B.notan1 + 0.60(0.90*B.notan2 + notaaps))  AS [Média Final]
FROM	tQuiManha. ALUNO 		AS  A, 
		tQuiManha. BOLETIM  	AS  B, 
		tQuiManha. CURSO  		AS  C,
		tQuiManha. DISCIPLINA  	AS  D
-- Definindo as junções EXPLICITAS com as tabelas declaradas nas linhas 33 até 36
WHERE	(B.ra = A.ra) AND (B.coddisciplina = D.coddisciplina) 
AND 	(A.codcurso = C.codcurso)
AND      C.codcurso = 120 AND a.ra = 100021;
