/* FMU - Faculdades Metropolitanas Unidas
   Cursos	     	: CST em Análise e Desenvolvimento de Sistemas
					  CST em Sistemas para Internet
			          BEL em Sistemas de Informação
			          BEL em Ciência da Computação
			          CST em BIG DATA
    Disciplina   	: Banco de Dados
    Objetivo	 	: Exercitar comandos DML.
                      Neste script veremos a sintaxe geral para ALTERAR (UPDATE) informações em uma
				      COLUNA de em uma tabela no Banco de Dados
    Data			: Primeiro Semestre 2023
----------------------------------------------------------------------------------------------  
                                        Sintaxe padrão
----------------------------------------------------------------------------------------------	
	Selecionar o banco
USE [BDFmuSegNoite]
GO
-- Utilizar a sintaxe do comando UPDATE
UPDATE [Nome do schema].[Nome da tabela]
-- Definir a coluna que será alterada e o novo valor que a coluna receberá
       coluna que será alterada 		Novo valor da coluna
   SET [chavematricula] 			= <chavematricula, char(15),>
      ,[codmatricula] 				= <codmatricula, char(11),>
      ,[ra] 						= <ra, int,>
      ,[codcurso] 					= <codcurso, int,>
      ,[serie] 						= <serie, smallint,>
      ,[coddisciplina] 				= <coddisciplina, int,>
      ,[sigladisciplina] 			= <sigladisciplina, varchar(17),>
      ,[notan1] 					= <notan1, decimal(5,2),>
      ,[notan2] 					= <notan2, decimal(5,2),>
      ,[notaaps] 					= <notaaps, decimal(5,2),>
 WHERE <Critérios de Pesquisa,,>
GO
--*/
USE [BDFmuSegNoite]
GO
UPDATE [tQuiManha].[BOLETIM]
   SET [notan1] 	= 3.5
   -- Observer que é possível, para o novo valor, utilizar expressões matemáticas.
      ,[notan2] 	= notan2+2.5
      ,[notaaps] 	= notaaps*0.9
 WHERE ra=99999 and coddisciplina=1231
GO