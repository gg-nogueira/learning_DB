/* FMU - Faculdades Metropolitanas Unidas
   Cursos	     	: CST em Análise e Desenvolvimento de Sistemas
					  CST em Sistemas para Internet
			          BEL em Sistemas de Informação
			          BEL em Ciência da Computação
			          CST em BIG DATA
    Disciplina   	: Banco de Dados
    Objetivo	 	: Exercitar comandos DML.
                      Neste script veremos a sintaxe geral para inserir linhas (tuplas)
				      em uma tabela no Banco de Dados, utilizando subqueries.
    Data			: Primeiro Semestre 2023
----------------------------------------------------------------------------------------------  
                                        Sintaxe padrão
----------------------------------------------------------------------------------------------	
	Selecionar o banco
USE [BDFmuSegNoite]
GO
-- Utilizar a sintaxe do comando UPDATE
UPDATE [Nome do schema].[Nome da tabela]
-- Definir a coluna que será alterada e o novo valor que a coluna receberá
       coluna que será alterada 		Novo valor da coluna
   SET [chavematricula] 			= <chavematricula, char(15),>
      ,[codmatricula] 				= <codmatricula, char(11),>
      ,[ra] 						= <ra, int,>
      ,[codcurso] 					= <codcurso, int,>
      ,[serie] 						= <serie, smallint,>
      ,[coddisciplina] 				= <coddisciplina, int,>
      ,[sigladisciplina] 			= <sigladisciplina, varchar(17),>
      ,[notan1] 					= <notan1, decimal(5,2),>
      ,[notan2] 					= <notan2, decimal(5,2),>
      ,[notaaps] 					= <notaaps, decimal(5,2),>
 WHERE <Critérios de Pesquisa,,>
GO
--*/
-- Selecionar / Dar foco no banco destino
USE [BDFmuSegNoite]
-- Criação de uma tabela que receberá as informações
CREATE TABLE tQuiManha.HISTORICO0123
(	ra int 			not null,
	nomealuno 		varchar(100) 	not null,
	nomedisciplina 	varchar(80) 	not null,
	mediabimestral 	decimal(5,2) 	not null, 
 );
-- Definir as linhas / tuplas que será inseridas na tabela 
INSERT INTO tQuiManha.HISTORICO0123 (ra, nomealuno, nomedisciplina, mediabimestral)
-- O resultado da consulta abaixo (Linhas 45 a 53 será inserida na tabela recem criada
SELECT 		A.ra, A.nomealuno, D.nomedisciplina, (0.40*B.nota1 + 0.60*(0.90*B.nota2+notaaps))
FROM 		tQuiManha.ALUNO A, 
            tQuiManha.BOLETIM B, 
			tQuiManha.CURSO C, 
            tQuiManha.DISCIPLINA D
-- Na linha 54, estamos estabelecendo a junção (IMPLICITA) das tabelas declaradas nas linhas 
-- 48 a 51 			
WHERE 		(B.ra = A.ra)  AND (B.coddisciplina = D.coddisciplina) 
AND 
            (A.codcurso = C.codcurso)
-- Filtrando apenas o curso cujo código é 120			
AND          A.codcurso ='120'
-- Colocando em ordem (classificando) pelo nome da Disciplina
-- Considerando que não acrescentamos nenhum parametro à cláusula ORDER BY
-- significa que por default a ordenação será ASCendente
ORDER BY 	 D.nomedisciplina;
