/* FMU - Faculdades Metropolitanas Unidas
-- Cursos	:CST em An�lise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informa��o
			 BEL em Ci�ncia da Computa��o
			 CST em BIG DATA
-- Objetivo	:Inserir um grupo de tuplas no banco de dados criado em sala, na tabela
             VALORCURSO 
-- Data: Primeiro Semestre 2023
-- Aplica-se toda vez em que tiver a necessidade de inserir acima de 1000 tuplas
   O INSERT faz parte do roll de instru��es SQL/ISO
*/
USE BDFmuSegNoite;
-- Abertura do banco de dados
--
--SET LANGUAGE us_english; -- Set"ando" a data do sistema que est� no formato Portugues para o formato Ingles
--SET DATEFORMAT dmy
---
INSERT INTO tSegNoite.VALORCURSO (codcurso,semletivo,ano,valor,majorado)
VALUES
(120,1,2023,1302,'01/01/23'),
(121,1,2023,1796,'01/01/23'),
(122,1,2023,1229,'01/01/23'),
(123,1,2023,1704,'01/01/23'),
(124,1,2023,1417,'01/01/23'),
(125,1,2023,1481,'01/01/23'),
(126,1,2023,1693,'01/01/23'),
(127,1,2023,1584,'01/01/23'),
(128,1,2023,1712,'01/01/23'),
(129,1,2023,1358,'01/01/23'),
(130,1,2023,1297,'01/01/23'),
(131,1,2023,1659,'01/01/23'),
(132,1,2023,1350,'01/01/23'),
(133,1,2023,1691,'01/01/23'),
(134,1,2023,1371,'01/01/23'),
(135,1,2023,1394,'01/01/23'),
(136,1,2023,1217,'01/01/23'),
(137,1,2023,1779,'01/01/23'),
(138,1,2023,1572,'01/01/23'),
(139,1,2023,1541,'01/01/23'),
(140,1,2023,1784,'01/01/23'),
(141,1,2023,1348,'01/01/23'),
(142,1,2023,1303,'01/01/23'),
(143,1,2023,1532,'01/01/23');