/* FMU - Faculdades Metropolitanas Unidas
-- Cursos	:CST em An�lise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informa��o
			 BEL em Ci�ncia da Computa��o
			 CST em BIG DATA
-- Objetivo	:Inserir um grupo de tuplas no banco de dados criado em sala, na tabela
             BOLSA 
-- Data: Primeiro Semestre 2023
-- Aplica-se toda vez em que tiver a necessidade de inserir acima de 1000 tuplas
   O INSERT faz parte do roll de instru��es SQL/ISO
*/
USE BDFmuSegNoite;
-- Abertura do banco de dados
--
--SET LANGUAGE us_english; -- Set"ando" a data do sistema que est� no formato Portugues para o formato Ingles
--SET DATEFORMAT dmy
---
INSERT INTO tSegNoite.BOLSA (codbolsa,tipobolsa,esconto)
VALUES
(100,'FIES',1.00),
(101,'PROUNI',0.80),
(102,'RECPROP',0.60),
(103,'PRAVALER',0.50),
(104,'CNPq',1.00),
(105,'CONVENIO',0.50),
(99,'Integral',0.00);