/* FMU - Faculdades Metropolitanas Unidas
-- Cursos	:CST em An�lise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informa��o
			 BEL em Ci�ncia da Computa��o
			 CST em BIG DATA
-- Objetivo	:Inserir um grupo de tuplas no banco de dados criado em sala, na tabela
             CURSO 
-- Data: Primeiro Semestre 2023
-- Aplica-se toda vez em que tiver a necessidade de inserir menos do que 1000 tuplas
-- Esta � uma limita��o do MS SQL Server
   O INSERT faz parte do roll de instru��es SQL/ISO
*/
USE BDFmuSegNoite;
-- Abertura do banco de dados
--
--SET LANGUAGE us_english; -- Set"ando" a data do sistema que est� no formato Portugues para o formato Ingles
--SET DATEFORMAT dmy
---
/* A sintaxe, padr�o SQL/ISO � a seguinte:
INSERT INTO (Nome do Schema).(Nome da tabela) (Rela��o das colunas que receber�o informa��es)
Na declara��o das colunas deve-se observar a mesma ordem estabelecida no momento da cria��o DANGLING
tabela.
Na sequ�ncia inserir a cl�usula VALUES.
Na linha seguinte � declara��o da cl�sula VALUES, deve-se:
   apor o parentese "(";
   inserir os valores separados por v�rgula
   ap�s a inser��o do valor relativo � �ltima coluna dever encerrar a linha (tupla) com
   parentese ")" seguido de 1 virgula, se haver mais tuplas para inserir OU ";" se for apenas
   1 tupla.
   Caso tenha mais de uma linha para ser inserida, deve-se apor ")" seguido de 1 virgula 
   em todas a linhas, exceto a �ltima que dever� ser finalizada com ")" e ";"
*/
INSERT INTO CURSO (codcurso,siglacurso,nomecurso,integralizacao,autorizacao,reconhecimento,notarec)
VALUES
(120,'ADM','Bacharelado em Administra��o',9,'17/02/10','17/02/19',4),
(121,'CCOMP','Bacharelado em Ci�ncia da Computa��o',9,'23/09/95','23/09/04',5),
(122,'CCONT','Bacharelado em Ci�ncias Cont�beis',9,'02/02/80','02/02/89',4),
(123,'MATE','Bacharelado em Matem�tica',9,'24/01/94','24/01/03',4),
(124,'PEDA','Bacharelado em Pedagogia',9,'28/06/82','28/06/91',4),
(125,'SISINF','Bacharelado em Sistemas de Informa��o',9,'03/02/14','03/02/23',4),
(126,'ADSI','CST em An�lise e Desenvolvimento de Sistemas',6,'25/08/98','25/08/04',5),
(127,'BD','CST em Banco de Dados',6,'22/01/85','22/01/91',4),
(128,'BDIA','CST em Big Data e Intelig�ncia Anal�tica',6,'27/02/01','27/02/07',5),
(129,'BLCD','CST em Blockchain e Criptografia Digital',6,'12/12/85','12/12/91',5),
(130,'ICCN','CST em Internet das Coisas e Computa��o em Nuvem',6,'13/12/88','13/12/94',5),
(131,'JGDI','CST em Jogos Digitais',6,'22/08/19','22/08/25',4),
(132,'REDES','CST em Redes de Computadores',6,'16/06/00','16/06/06',5),
(133,'SECEX','CST em Secretariado Executivo',6,'07/03/94','07/03/00',4),
(134,'SGIN','CST em Seguran�a da Informa��o',6,'12/11/91','12/11/97',4),
(135,'SIDM','CST em Sistemas para Internet (Desenvolvimento Mobile)',6,'16/06/92','16/06/98',4),
(136,'ENCP','Engenharia da Computa��o',6,'14/10/81','14/10/87',5),
(137,'LIPE','Licenciatura em em Pedagogia',6,'26/05/82','26/05/88',4),
(138,'LICM','Licenciatura em Matem�tica',6,'31/08/94','31/08/00',5),
(139,'GTI','CST em Gest�o da Tecnologia da Informa��o',6,'31/08/95','31/08/01',5),
(140,'RH','CST em Recursos Humanos',6,'31/08/96','31/08/01',4),
(141,'GFIN','CST em Gest�o Financeira',6,'31/08/97','31/08/03',4),
(142,'LOG','CST em Logistica e Transportes',6,'31/08/98','31/08/04',5),
(143,'MARK','CST em Gest�o em Marketing',6,'31/08/99','31/08/05',5);