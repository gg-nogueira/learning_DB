/* FMU - Faculdades Metropolitanas Unidas
   Cursos	  : CST em Análise e Desenvolvimentão de Sistemas
                CST em Sistemas para Internet
			    CST em BIG DATA
			    CST em Gestão da Tecnologia da Informação
			    BEL em Sistemas de Informação
			    BEL em Ciência da Computação
    Disciplina: Banco de Dados
    Objetivo  : Criar o Banco de Dados e Tabelas para suporte ao curso de SQL
    Data      : Primeiro Semestre 2023

    CRIAÇÃO DO DATABASE SE ELE NÃO EXISTIR
--*/
IF NOT EXISTS
   (
--	Esta parte do Script verifica nos objetos do dicionário de dados que
--	se encontram no master.dbo chamado de sysdatabases se existe
-- 	Banco de Dados com o nome definido da cláusula WHERE
-- 	Se nao existir, ele executará as instruções na primeira linha logo após o parenteses ")".
	Caso contrário o SQL Server executará a instrução da linha 30
	 SELECT name
	 FROM master.dbo.sysdatabases
     WHERE name = 'BDFmuSegNoite'
    )
CREATE DATABASE BDFmuSegNoite
GO
-- Slides 90 a 92
-- CRIAÇÃO DO SCHEMA
-- Dar foco para o DATABASE que queremos criar o SCHEMA
USE BDFmuSegNoite;
-- O comando GO é usado para agrupar comandos SQL em lotes que são enviados jáuntos ao servidor
GO
--
-- Inicio do próximo lote de comandos
-- Slides 93 a 116
IF NOT EXISTS
	(
--	Esta parte do Script verifica nos objetos do dicionário de dados que
--	se encontram no sys.schemas se existe o SCHEMA com o nome definido da cláusula WHERE
-- 	Se não ele executa as instruções na linha 45, caso contrário as instruções da linha 47
	  SELECT SCHEMA_ID
	  FROM sys.schemas
	  WHERE [name] = 'tSegNoite'
	)
EXEC('CREATE SCHEMA tSegNoite')
GO
USE BDFmuSegNoite;
GO
--
-- Inicio do próximo lote de comandos para criação de TABELAS
--
/* O lote de instruções linhas 53 a 63 são opcionais.
   Este lote de comando que tem inicio na linha 53, começa testando se
   se a TABELA que queremos criar EXISTE.
   Se a função OBJECT_ID retornar NULL, significa que a TABELA no EXISTE,
   casão contrário a tabela já existe e então precisamos excluí-la antes de
   recriá-la
*/
IF OBJECT_ID(N'tSegNoite.CURSO','U') IS NOT NULL
/* 	OBJECT_ID é uma função do T-SQL que identifica se objetos de dados
-- 	como tabela, views, indices existe. onde:
	'U' é um object type que faz referencia a uma TABELA,
  	'V' é um object type que faz referencia a uma View,ele
	'P' é um object type que faz referencia a "store procedure", etc..
	Neste exemplo a função está verificando de a tabela CURSO existe. Se a tabela existir
	ela será DROP(ada), caso contrário o controle é passado para a linha 73
*/
	DROP TABLE tSegNoite.CURSO;
	GO
--
-- Criação da tabela tSegNoite.CURSO
--
CREATE TABLE tSegNoite.CURSO
(
	codcurso			int			not null,
	siglacurso      	varchar(10) not null,
	nomecurso			varchar(50)	not null,
	integralizacao		smallint	not null,
	autorizacao			date		not null,
	reconhecimento		date				,
	notareconhecimento  decimal(5,2)not null,
	/* Definição da Chave Primária (PK) da tabela curso	*/
	CONSTRAINT PK_CURSO_codcurso PRIMARY KEY (codcurso)
);
GO
/* é necessário aqui uma observação sobre a definição da chave primária
   Na frase: CONSTRAINT PK_CURSO_codcurso PRIMARY KEY (codcurso)
             CONSTRAINT é o comando para definição de uma chave primária (PK) ou
			            chave estrangeira (FK)
			 PK_CURSO_codcurso é o nome da chave primária. é um mnemônico que
			 facilita a identificação da chave, vez que
			 PK refere-se ao tipo de caso, neste caso chave primária
			 CURSO refere-se a qual tabela pertence a chave primária
			 codcurso é a coluna selecionada para receber este status, isto é,
			 chave primária.
			 PRIMARY KEY é a definição da chave
*/
--
--Criacao da tabela VALORCURSO
--
CREATE TABLE tSegNoite.VALORCURSO
(
	codcurso	int				not null,
	semletivo	smallint 		not null,
	ano			smallint 		not null,
	valor		decimal(8,2)	not null,
	majoracao	DATE 			not null
	/* Definição da Chave Primária (PK) da tabela curso	*/
	CONSTRAINT PK_VALORCURSO_codcurso PRIMARY KEY (codcurso)
);
GO	
--
--Criacao da tabela BOLSA
--
CREATE TABLE tSegNoite.BOLSA
(
	codbolsa	int				not null,
	tipobolsa	varchar(10)		not null,
	desconto	decimal(3,2)	not null
	/* Definição da Chave Primária (PK) da tabela curso	*/
	CONSTRAINT PK_BOLSA_codbolsa PRIMARY KEY (codbolsa)
);
GO
--
--Criacao da tabela DEPARTAMENTO
--
CREATE TABLE tSegNoite.DEPARTAMENTO
(
	coddepto		int			not null,
	nomedepto		varchar(50)	not null,
	codfaculdade	int			not null,
	codcoordenador	int			not null
	CONSTRAINT PK_DEPARTAMENTO_coddepto PRIMARY KEY (coddepto)
);
--
-- Criação da tabela PROFESSOR
--
CREATE TABLE tSegNoite.PROFESSOR
(
	codprofessor	int	not     null,
	nomeprof		varchar(40)	not null,
	titulacao 		varchar(12) not null,
	coddepto		int			not null
	CONSTRAINT PK_PROFESSOR_codprofessor 	PRIMARY KEY (codprofessor),
	CONSTRAINT FK_PROFESSOR_coddepto 		FOREIGN KEY (coddepto) REFERENCES tSegNoite.DEPARTAMENTO (coddepto),
);
--
-- Criacao da tabela DISCIPLINA
--
CREATE TABLE tSegNoite.DISCIPLINA
(
	coddisciplina	int			not null,
	chavedisciplina varchar(17)	not null,
	codcurso		int			not null,
	coddepto		int			not null,
	nomedisciplina	varchar(50)	not null,
	seriecurso      smallint    not null
	CONSTRAINT PK_DISCIPLINA_coddisciplina 	PRIMARY KEY (coddisciplina),
	CONSTRAINT FK_DISCIPLINA_codcurso 		FOREIGN KEY (codcurso) REFERENCES tSegNoite.CURSO(codcurso),
	CONSTRAINT FK_DISCIPLINA_coddepto 		FOREIGN KEY (coddepto) REFERENCES tSegNoite.DEPARTAMENTO(coddepto)
);
--
--Criação da tabela MATRICULA
--
CREATE TABLE tSegNoite.MATRICULA
(
	chavematricula 	char(15) 	not null,
	codmatricula 	char(11) 	not null,
	ra				int		 	not null,
	codcurso		int		 	not null,
	serie 			smallint 	not null,
	codturno 		smallint 	not null,
	codunidade 		smallint 	not null,
	unidade 		varchar(10) not null,
	codturma 		char(07) 	not null,
	siglaturno 		char(02)	not null,
	tipocurso 		varchar(12) not null,
	datamatricula 	date 		not null,
	coddisciplina 	int 		not null,
	acrondisciplina varchar(17) not null,
	situacao		varchar(11) not null
	CONSTRAINT PK_MATRICULA_chavematricula 	PRIMARY KEY (chavematricula),
	CONSTRAINT FK_MATRICULA_codcurso		FOREIGN KEY (codcurso) 		REFERENCES tSegNoite.CURSO (codcurso),
	CONSTRAINT FK_MATRICULA_coddisciplina	FOREIGN KEY (coddisciplina) REFERENCES tSegNoite.DISCIPLINA (coddisciplina)
);
--
-- Criação da tabela GENERO
--
CREATE TABLE tSegNoite.GENERO
(	
	codgenero		smallint		not null,	
	genero			varchar(070)	not null,
--  descricao		varchar(200)
	CONSTRAINT PK_GENERO_codgenero PRIMARY KEY (codgenero)	
);
--
-- Criação da tabela ESTADOCIVIL
--
CREATE TABLE tSegNoite.ESTADOCIVIL
(	
	codecivil		smallint	not null,	
	estadocivil		varchar(10)	not null
	CONSTRAINT PK_GENERO_codecivil PRIMARY KEY (codecivil)
);
--
--Criação da tabela ALUNO
--
CREATE TABLE tSegNoite.ALUNO
(
	ra       	int 			not null,
	nomealuno 	varchar(100) 	not null,
	codcurso  	int 			not null,
	sexo      	smallint 		not null,
	estadocivil char(05) 		not null,
	idade       smallint 		not null,
	logradouro 	varchar(16),
	endereco 	varchar(100),
	numero 		smallint,
	complemento varchar(100),
	bairro 		varchar(60),
	cidade 		varchar(40),
	uf 			varchar(03),
	regiao 		varchar(16),
	pais 		char(02),
	cep 		char(08),
	email 		varchar(60),
	telefone 	varchar(20),
	situacao    varchar(11) 	not null
	CONSTRAINT PK_ALUNO_ra       PRIMARY KEY (ra),
	CONSTRAINT FK_ALUNO_codcurso FOREIGN KEY (codcurso) REFERENCES tSegNoite.CURSO  (codcurso),
	CONSTRAINT FK_ALUNO_sexo	 FOREIGN KEY (sexo) 	REFERENCES tSegNoite.GENERO (codgenero)	
);
/* é necessário aqui uma observação sobre a definição da chave estrangeira
   Na frase: CONSTRAINT FK_ALUNO_codcurso FOREIGN KEY(codcurso) REFERENCES tSegNoite.CURSO(codcurso)
             CONSTRAINT é o comando para definição de uma chave primária (PK) ou
			            chave estrangeira (FK)
			 FK_ALUNO_codcurso é o nome da chave primária. é um mnemônico que
			 facilita a identificação da chave, vez que
			 FK refere-se ao tipo de caso, neste caso chave estrangeira
			 ALUNO refere-se a qual tabela pertence a chave estrangeira
			 codcurso é a coluna selecionada para receber este status, isto é,
			 chave estrangeira.
			 FOREIGN KEY é a definição da chave estrangeira
			 REFERENCES é o parâmetro para estabelecer a relação / assãociação entre
			 as tabelas: ALUNO e CURSO
*/			
--
-- Criação da tabela BOLSISTA
--
CREATE TABLE tSegNoite.BOLSISTA
(
	ra       	int 			not null,
	codcurso  	int 			not null,
	codbolsa   	int 		    not null
	CONSTRAINT PK_BOLSISTA_ra       PRIMARY KEY (ra),
	CONSTRAINT FK_BOLSISTA_codcurso FOREIGN KEY (codcurso)  REFERENCES tSegNoite.CURSO (codcurso),
	CONSTRAINT FK_BOLSISTA_codbolsa	FOREIGN KEY (codbolsa)	REFERENCES tSegNoite.BOLSA (codbolsa)	
);
--
-- Criação da tabela BOLETIM
--
CREATE TABLE tSegNoite.BOLETIM
(
	chavematricula	char(15)	not null,
	codmatricula 	char(11) 	not null,
	ra				int  		not null,
	codcurso 		int 		not null,
	serie 			smallint 	not null,
	coddisciplina	int			not null,
	sigladisciplina	varchar(17) not null,
	notan1			decimal(5,2),
	notan2			decimal(5,2),
	notaaps			decimal(5,2)
	CONSTRAINT PK_BOLETIM_codmatricula	 	PRIMARY KEY (codmatricula),
	CONSTRAINT FK_BOLETIM_codcurso 			FOREIGN KEY (codcurso)      REFERENCES tSegNoite.CURSO (codcurso),
	CONSTRAINT FK_BOLETIM_coddisciplina     FOREIGN KEY (coddisciplina) REFERENCES tSegNoite.DISCIPLINA (coddisciplina)
);
--
--Criação da tabela GRADE
--
CREATE TABLE tSegNoite.GRADE
(
	codmatricula 	char(11) 	not null,
	chavematricula	char(15) 	not null,
	unidade			varchar(10) not null,
	codcoordenador 	int 		not null,
	siglacurso      char(06)	not null,
	codcurso		char(03)	not null,
	serie 			smallint 	not null,
	coddisciplina	int 		not null,
	anoagenda 		int 		not null,
	semletivo		smallint 	not null,
	sigladisciplina varchar(18) not null,
	codturma		char(07)	not null,
	siglaturno 		char(02)	not null,
	horario			char(12)	not null,
	diasemana 		varchar(13) not null,
	codprofessor 	int 		not null,
	titulacao		varchar(13) not null
	CONSTRAINT PK_GRADE_chavematricula 	PRIMARY KEY (chavematricula),
	CONSTRAINT FK_GRADE_codcoordenador 	FOREIGN KEY (codcoordenador) REFERENCES tSegNoite.PROFESSOR  (codprofessor),
	CONSTRAINT FK_GRADE_coddisciplina 	FOREIGN KEY (coddisciplina)  REFERENCES tSegNoite.DISCIPLINA (coddisciplina),
	CONSTRAINT FK_GRADE_codprofessor 	FOREIGN KEY (codprofessor)   REFERENCES tSegNoite.PROFESSOR (codprofessor)
);