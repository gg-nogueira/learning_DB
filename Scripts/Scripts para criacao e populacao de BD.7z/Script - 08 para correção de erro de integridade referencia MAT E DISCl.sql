/* FMU - Faculdades Metropolitanas Unidas
-- Cursos	:CST em Análise e Desenvolvimento de Sistemas
             CST em Sistemas para Internet
			 BEL em Sistemas de Informação
			 BEL em Ciência da Computação
			 CST em BIG DATA
-- Objetivo	:Inserir um grupo de tuplas no banco de dados criado em sala, na tabela
             DISCIPLINA 
-- Data: Primeiro Semestre 2023
-- O INSERT faz parte do roll de instruções SQL/ISO
*/
USE BDFmuSegNoite;
INSERT INTO tSegNoite.DISCIPLINA (coddisciplina,chavedisciplina,codcurso,coddepto,nomedisciplina,seriecurso)
VALUES 
(9999,'101_092_FA',120,215,'Disciplina fora do catálogo',1);
