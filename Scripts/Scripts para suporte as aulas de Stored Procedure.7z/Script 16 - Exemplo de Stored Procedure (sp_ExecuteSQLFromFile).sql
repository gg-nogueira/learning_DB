--------------------------------------------------------------------

Stored Procedure: sp_ExecuteSQLFromFile

--------------------------------------------------------------------
/*
Você pode ter muitos motivos para querer executar o código T-SQL a partir de um arquivo, mas um motivo vem à mente para mim: construir um banco de dados carregado do zero. Eu tenho um script mestre que cria um banco de dados vazio e executa várias pequenas tarefas. Entre cada tarefa, o script mestre também executa o código T-SQL de vários arquivos. Os arquivos contêm código para criar uma variedade de objetos de banco de dados e copiar dados. Os mesmos arquivos também são usados ​​para outras tarefas de administração do banco de dados.

Você também pode ter muitos motivos para evitar o osql, mas só consigo pensar em um: o osql é um utilitário de prompt de comando e, como tal, é usado por meio do procedimento armazenado estendido xp_cmdshell. Muitos administradores de banco de dados controlam estritamente quais usuários podem executar esse procedimento armazenado para evitar um risco potencial à segurança. A idéia por trás de escrever uma rotina personalizada para executar o código T-SQL de um arquivo é evitar a dependência de xp_cmdshell. No entanto, um dos procedimentos armazenados mencionados acima usa xp_cmdshell para importar o arquivo para uma tabela. Eu poderia ignorar essa escolha inexplicável se a rotina oferecesse recursos que o osql carece - mas esse não é o caso. Na verdade, a rotina impõe algumas limitações adicionais significativas.

Os dois procedimentos armazenados em questão têm várias outras deficiências. Uma ou ambas as rotinas impõem:

Tamanho máximo do arquivo de 80 KB.
Tamanho máximo do lote de 8 KB.
Limitação de lote único dentro do arquivo, reforçada pela remoção de quaisquer separadores de lote ("GO"). Tal ação tornaria muitos arquivos de script inúteis.
Comprimento máximo da linha de aproximadamente 250 caracteres.
Ambas as rotinas usam o banco de dados temporário de uma forma estranha e arriscada. Um cria uma tabela de usuário normal em tempdb e o outro cria uma tabela temporária global, mas nenhum o faz por necessidade. Ambos correm o risco de conflito de nomes de tabela se duas conexões executam o procedimento armazenado ao mesmo tempo, o que pode ter algumas consequências desagradáveis. Um deles falha em garantir que as linhas do código T-SQL sejam executadas na ordem em que aparecem no arquivo e o outro falha em preservar o formato do código T-SQL. O formato do código é importante quando objetos de banco de dados (como procedimentos armazenados) são criados por esse código.

O procedimento armazenado do sistema apresentado nesta dica aborda essas deficiências: Ele não impõe um tamanho máximo de arquivo. Ele permite tamanhos de lote de até 80 KB. Ele permite um número efetivamente ilimitado de lotes no arquivo. Ele permite milhares de caracteres em uma linha de código T-SQL. Esta rotina usa o banco de dados temporário de forma padrão e segura. Ele garante que as linhas do código T-SQL sejam executadas na ordem correta e preserva o formato do código T-SQL conforme ele existe no arquivo. Obviamente, esse procedimento armazenado não depende de xp_cmdshell ou osql e oferece um recurso que falta ao osql.

O código SQL na Listagem 1 cria um procedimento armazenado do sistema denominado sp_ExecuteSQLFromFile. A rotina lê um arquivo especificado e processa o conteúdo como lotes de código T-SQL. Cada lote deve terminar com a palavra "GO" em uma linha, que é o separador de lote padrão em arquivos T-SQL. A rotina retorna opcionalmente um conjunto de resultados contendo informações sobre cada lote T-SQL no arquivo. O conjunto de resultados inclui números de lote, localizações dentro do arquivo (primeira e última linha), contagens de linha, períodos de execução (horas de início e término), tempos decorridos e códigos de erro.

O código SQL na Listagem 1 também cria um arquivo de formato no diretório de programa do SQL Server ("C: \ Arquivos de Programas \ Microsoft SQL Server \ File.fmt"). O local pode ser alterado modificando a Listagem 1 em dois lugares. O procedimento armazenado estendido xp_cmdshell é usado para criar o arquivo de formato. A capacidade de executar xp_cmdshell é necessária apenas quando o procedimento armazenado sp_ExecuteSQLFromFile é criado e apenas pelo usuário que está fazendo a criação. Essa é uma operação muito diferente do que realmente executar sp_ExecuteSQLFromFile.

O arquivo de formato é usado ao importar o código T-SQL de um arquivo para uma tabela temporária com a instrução BULK INSERT. O arquivo de formato permite que uma coluna IDENTITY exista na tabela temporária. A coluna IDENTITY fornece uma maneira de ordenar as linhas da tabela temporária ao montar o código T-SQL a ser executado. A menos que uma cláusula ORDER BY seja usada na instrução SELECT envolvida, não há garantia de que as linhas sejam retornadas na ordem em que aparecem no arquivo.

O procedimento armazenado sp_ExecuteSQLFromFile aceita até três parâmetros, mas apenas um deles é necessário.

O primeiro parâmetro (@PCFetch) especifica a localização do arquivo de código T-SQL. O parâmetro deve fornecer um caminho completo, incluindo o nome do arquivo, para o arquivo de código T-SQL desejado. A conta de serviço do SQL Server deve ter permissão para ler arquivos nesse local.

O segundo parâmetro (@PCAdmin) é opcional e especifica a localização do arquivo de formato. O parâmetro deve fornecer um caminho completo, incluindo o nome do arquivo, para o arquivo de formato. O local padrão é um arquivo denominado "File.fmt" no diretório de programa do SQL Server ("C: \ Arquivos de Programas \ Microsoft SQL Server \ File.fmt"). O código SQL na Listagem 1 cria um arquivo de formato nesse local.

O terceiro parâmetro (@PCUltra) é opcional e especifica se um conjunto de resultados de informações do lote é retornado. Um valor zero (0) significa nenhum conjunto de resultados. Um valor de um (1) significa que um conjunto de resultados é retornado com uma linha para cada lote no arquivo.

O exemplo abaixo é apenas para fins ilustrativos. O caminho deve ser alterado para um local apropriado para seu ambiente.

EXECUTE sp_ExecuteSQLFromFile 'D: \ Scripts \ Script.sql', NULL, 1
*/

USE master
GO
CREATE PROCEDURE dbo.sp_ExecuteSQLFromFile
    @PCFetch varchar(1000),
    @PCAdmin varchar(1000) = NULL,
    @PCUltra bit = 0
AS

SET NOCOUNT ON

DECLARE @Return int
DECLARE @Retain int
DECLARE @Status int

SET @Status = 0

DECLARE @Task varchar(2000)

DECLARE @Work varchar(2000)

DECLARE @Line varchar(8000)

DECLARE @SQL1 varchar(8000)
DECLARE @SQL2 varchar(8000)
DECLARE @SQL3 varchar(8000)
DECLARE @SQL4 varchar(8000)
DECLARE @SQL5 varchar(8000)
DECLARE @SQL6 varchar(8000)
DECLARE @SQL7 varchar(8000)
DECLARE @SQL8 varchar(8000)
DECLARE @SQL9 varchar(8000)

DECLARE @CRLF    char(2)

DECLARE @Save tinyint

DECLARE @Have     int

DECLARE @SQLA     int
DECLARE @SQLZ     int
DECLARE @SQLN     int

DECLARE @BOLA datetime
DECLARE @BOLZ datetime
DECLARE @BOLN datetime

CREATE TABLE #DBAT (Line varchar(8000), Work int IDENTITY(1,1))

CREATE TABLE #DBAZ (Batch int, SQLA int, SQLZ int, SQLN int, BOLA datetime, BOLZ datetime, BOLN datetime, Status int)

SET @CRLF = CHAR(13) + CHAR(10)

SET @SQL1 = ''
SET @SQL2 = ''
SET @SQL3 = ''
SET @SQL4 = ''
SET @SQL5 = ''
SET @SQL6 = ''
SET @SQL7 = ''
SET @SQL8 = ''
SET @SQL9 = ''

SET @Save = 1

SET @Have = 0

SET @SQLA = 1

SET @PCAdmin = ISNULL(@PCAdmin,'C:\Program Files\Microsoft SQL Server\File.fmt')

SET @Task = 'BULK INSERT #DBAT FROM ' + CHAR(39) + @PCFetch + CHAR(39) + ' WITH (FORMATFILE = ' + CHAR(39) + @PCAdmin + CHAR(39) + ')'

EXECUTE (@Task)

SET @Return = @@ERROR IF @Status = 0 SET @Status = @Return

DECLARE Lines CURSOR FAST_FORWARD FOR SELECT ISNULL(Line,''), Work FROM #DBAT ORDER BY Work

OPEN Lines

FETCH NEXT FROM Lines INTO @Line, @SQLZ

WHILE @@FETCH_STATUS = 0 AND @Status = 0

    BEGIN

    IF UPPER(LTRIM(RTRIM(@Line))) = 'GO'

        BEGIN

        SET @BOLA = GETDATE()

        SET @Have = @Have + 1

        EXECUTE (@SQL1+@SQL2+@SQL3+@SQL4+@SQL5+@SQL6+@SQL7+@SQL8+@SQL9)

        SET @Return = @@ERROR -- IF @Status = 0 SET @Status = @Return

        SET @BOLZ = GETDATE()

        SET @SQLN = @SQLZ - @SQLA

        SET @BOLN = @BOLZ - @BOLA

        INSERT #DBAZ VALUES (@Have, @SQLA, @SQLZ, @SQLN, @BOLA, @BOLZ, @BOLN, @Return)

        SET @SQL1 = ''
        SET @SQL2 = ''
        SET @SQL3 = ''
        SET @SQL4 = ''
        SET @SQL5 = ''
        SET @SQL6 = ''
        SET @SQL7 = ''
        SET @SQL8 = ''
        SET @SQL9 = ''

        SET @Save = 1

        SET @BOLA = GETDATE()

        SET @SQLA = @SQLZ + 1

        END
        ELSE
        BEGIN

        IF @Save = 1 IF DATALENGTH(@SQL1) + DATALENGTH(@Line) < 7998 SET @SQL1 = @SQL1 + @Line + @CRLF ELSE SET @Save = 2
        IF @Save = 2 IF DATALENGTH(@SQL2) + DATALENGTH(@Line) < 7998 SET @SQL2 = @SQL2 + @Line + @CRLF ELSE SET @Save = 3
        IF @Save = 3 IF DATALENGTH(@SQL3) + DATALENGTH(@Line) < 7998 SET @SQL3 = @SQL3 + @Line + @CRLF ELSE SET @Save = 4
        IF @Save = 4 IF DATALENGTH(@SQL4) + DATALENGTH(@Line) < 7998 SET @SQL4 = @SQL4 + @Line + @CRLF ELSE SET @Save = 5
        IF @Save = 5 IF DATALENGTH(@SQL5) + DATALENGTH(@Line) < 7998 SET @SQL5 = @SQL5 + @Line + @CRLF ELSE SET @Save = 6
        IF @Save = 6 IF DATALENGTH(@SQL6) + DATALENGTH(@Line) < 7998 SET @SQL6 = @SQL6 + @Line + @CRLF ELSE SET @Save = 7
        IF @Save = 7 IF DATALENGTH(@SQL7) + DATALENGTH(@Line) < 7998 SET @SQL7 = @SQL7 + @Line + @CRLF ELSE SET @Save = 8
        IF @Save = 8 IF DATALENGTH(@SQL8) + DATALENGTH(@Line) < 7998 SET @SQL8 = @SQL8 + @Line + @CRLF ELSE SET @Save = 9
        IF @Save = 9 IF DATALENGTH(@SQL9) + DATALENGTH(@Line) < 7998 SET @SQL9 = @SQL9 + @Line + @CRLF ELSE SET @Save = 0

        END

    FETCH NEXT FROM Lines INTO @Line, @SQLZ

    END

CLOSE Lines DEALLOCATE Lines

IF DATALENGTH(@SQL1) > 0 AND @Status = 0

    BEGIN

    SET @BOLA = GETDATE()

    SET @Have = @Have + 1

    EXECUTE (@SQL1+@SQL2+@SQL3+@SQL4+@SQL5+@SQL6+@SQL7+@SQL8+@SQL9)

    SET @Return = @@ERROR -- IF @Status = 0 SET @Status = @Return

    SET @BOLZ = GETDATE()

    SET @SQLN = @SQLZ - @SQLA + 1

    SET @BOLN = @BOLZ - @BOLA

    INSERT #DBAZ VALUES (@Have, @SQLA, @SQLZ, @SQLN, @BOLA, @BOLZ, @BOLN, @Return)

    END

IF @PCUltra <> 0

    BEGIN

      SELECT Batch
           , SQLA AS LineFrom
           , SQLZ AS LineThru
           , SQLN AS CodeSize
           , CONVERT(char(12),BOLA,14) AS TimeFrom
           , CONVERT(char(12),BOLZ,14) AS TimeThru
           , CONVERT(char(12),BOLN,14) AS Duration
           , Status
        FROM #DBAZ
    ORDER BY Batch

    END

DROP TABLE #DBAT

DROP TABLE #DBAZ

SET NOCOUNT OFF

RETURN (@Status)

GO

DECLARE @Task varchar(1000)
DECLARE @Work varchar(2000)

SET @Task = ' PRINT ' + CHAR(39) + '7.0' + CHAR(39)
          + ' PRINT ' + CHAR(39) + '1'   + CHAR(39)
          + ' PRINT ' + CHAR(39) + '1 SQLCHAR 0 8000 ' + CHAR(39) + ' + CHAR(34) + ' + CHAR(39) + '\r\n' + CHAR(39) + ' + CHAR(34) + ' + CHAR(39) + ' 1 Line SQL_Latin1_General_CP1_CI_AS' + CHAR(39)

SET @Work = 'osql -E -Q "' + @Task + '" -o "C:\Program Files\Microsoft SQL Server\File.fmt" -s "" -w 8000'

EXECUTE master.dbo.xp_cmdshell @Work, NO_OUTPUT

GO