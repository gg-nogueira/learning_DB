/* FMU - Faculdades Metropolitanas Unidas
-- Cursos	:CST em Sistemas para Internet
--           BEL Ci�ncia da Computa��o
-- Objetivo	:Exemplo Stored Procedure para calcular a mediana de determinada coluna na
             tabela BOLETIM
-- Data		:Primeito Semestre 2021
-- 
*/
CREATE PROCEDURE tManha.sp_calcMediana
--Paramentros recebidos pela Stored Procedure
  @schema VARCHAR(255),-- Nome do schema que ser� recebido
  @tabela VARCHAR(255),-- Nome da tabela que ser� recebido,
  @coluna VARCHAR(255) -- Nome da coluna que ser� recebida e atrav�s da qual ser�
                       -- Calculada a Mediana
AS
BEGIN
--Declara��o da vari�veis. Note que todo nome de vari�vel no SQL Server � precedido
--de um "@"
  DECLARE @total_registros INT;
  DECLARE @posicao_central INT;
  DECLARE @mediana FLOAT;
  DECLARE @full_table_name NVARCHAR(MAX);
  DECLARE @sql NVARCHAR(MAX);
--Concatenando o nome do schema com o nome da tabela. Ambos recebidos como parametros.
--A fun��o utilizada � a QUOTENAME
  SET @full_table_name = QUOTENAME(@schema) + '.' + QUOTENAME(@tabela);
/*Aqui introduzimos o conceito de dynamic SQL
  SQL din�mico � uma t�cnica para construir e executar instru��es SQL em tempo de 
  execu��o.Ele permite que voc� crie instru��es SQL dinamicamente, com base em par�metros
  de entrada
  No entanto, � importante usar o SQL din�mico com cuidado, pois pode apresentar riscos
  de seguran�a se n�o for usado corretamente. 
  Voc� deve sempre validar a entrada do usu�rio e usar consultas parametrizadas ou a 
  fun��o `QUOTENAME` para evitar ataques de inje��o de SQL.
*/
  SET @sql = N'
    -- Contando o total de registros no ROL
    SET @total_registros = (SELECT COUNT(' + QUOTENAME(@coluna) + N') FROM ' + @full_table_name + N');

    -- Calculando a posi��o central no ROL
    SET @posicao_central = (@total_registros + 1) / 2;

    -- Verificando se a quantidade de dados � par ou �mpar
    IF (@total_registros % 2 = 1) -- �mpar
    BEGIN
      -- Obtendo o valor do meio, da posi��o central
		SET @mediana = (SELECT ' + QUOTENAME(@coluna) + N'
						FROM 	(
									SELECT ' + QUOTENAME(@coluna) + N', ROW_NUMBER() OVER (ORDER BY ' + QUOTENAME(@coluna) + N' ASC) AS rn
									FROM ' + @full_table_name + N'
								) 	AS subquery
						WHERE rn = @posicao_central);
    END
    ELSE -- Par
    BEGIN
      -- Obtendo os valores centrais
		SET @mediana = 	(SELECT AVG(' + QUOTENAME(@coluna) + N')
                      FROM 	(
								SELECT ' + QUOTENAME(@coluna) + N', ROW_NUMBER() OVER (ORDER BY ' + QUOTENAME(@coluna) + N' ASC) AS rn
								FROM ' + @full_table_name + N'
							) 	AS subquery
                      WHERE rn IN (@posicao_central, @posicao_central + 1));
    END;

    -- Retornando a mediana
    SELECT @mediana AS mediana;
  ';

  EXEC sp_executesql @sql,
                     N'@schema VARCHAR(255), @tabela VARCHAR(255), @coluna VARCHAR(255), @total_registros INT OUTPUT, @posicao_central INT OUTPUT, @mediana FLOAT OUTPUT',
                     @schema,
                     @tabela,
                     @coluna,
                     @total_registros OUTPUT,
                     @posicao_central OUTPUT,
                     @mediana OUTPUT;

END;
