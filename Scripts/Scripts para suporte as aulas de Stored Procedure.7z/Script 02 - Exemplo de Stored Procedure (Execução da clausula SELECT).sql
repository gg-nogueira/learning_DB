-- FMU			: Faculdades Metropolitanas Unidas
-- Curso		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de dados I
-- Objetivo		: Exemplificar Stored Procedure
-- Data			: Prim Sem 
/*				: Stored Procedure para inserção de registro / tupla de um  ALUNO 
				  Este é um tipo de Store Procedure definido pelo usuário e, portanto,
				  será armazenado no em um banco de dados definido pelo usuário ou em 
				  todos os bancos de dados do sistema, exceto no banco de dados RESOURCE 
*/
CREATE PROCEDURE grp01.uSP_ExibirAllalunos
/* Perceba que uma SP está vinculada ao SCHEMA do banco, Logo, se não for tomado este cuidado 
   a SP será criada no SCHEMA default do SQL Server, isto é, dbo.
   Outro cuidade a ser tomado é com relação ao prefixo "Sp_". Este é o prefixo de toda Sp
   definida pelo SQL Server e que estão armazenada no Banco de Dados RESOURCE.

   Nas linha abaixo, temos as declaraçãoes das variáveis que serão utilizada na SP
*/
AS
BEGIN
SELECT * FROM grp01.ALUNO
END
