--------------------------------------------------------------------

Stored Procedure: sp_ListObjects

--------------------------------------------------------------------
/*
O código SQL na Listagem 1 cria um procedimento armazenado do sistema denominado sp_ListObjects. 
A rotina retorna uma lista de todos os objetos de banco de dados SQL Server atuais dos tipos 
selecionados. A lista inclui tipos de objeto, nomes de objeto, nomes de objeto pai 
(quando aplicável) e datas de criação (quando disponível).

O procedimento armazenado sp_ListObjects faz referência a tabelas de sistema do SQL Server. Você pode achar que é prudente rejeitar essa abordagem para rotinas de aplicativos de produção, mas deve servir para trabalho administrativo.

O procedimento armazenado sp_ListObjects aceita três parâmetros. Todos os três são opcionais. O primeiro parâmetro é uma lista de tipos de objetos específicos a serem incluídos. O segundo parâmetro é uma lista de tipos de objetos específicos a serem excluídos. O terceiro parâmetro seleciona entre dois conjuntos padrão de tipos de objetos a serem incluídos.

O primeiro e o segundo parâmetros são listas de tipos de objetos separados por barras verticais (barras verticais). Os efeitos dos parâmetros são combinados com um operador AND, portanto, normalmente, apenas um deles seria usado para uma determinada chamada.

O terceiro parâmetro entra em vigor apenas quando os dois primeiros parâmetros não são especificados (NULL). Nesse caso, um zero (0) retorna objetos de código e um (1) retorna objetos de estrutura. Os objetos de código são definidos como tipos V | P | FN | IF | TF | TR porque esses objetos geralmente consistem em código SQL. Objetos de estrutura são definidos como tipos U | K | F | C | D | I porque tais objetos definem a estrutura de um banco de dados.

Os tipos de objeto são:

V - visão
P - procedimento armazenado
FN - função definida pelo usuário, escalar
IF - função definida pelo usuário, valor de tabela,
TF em linha - função definida pelo usuário, valor de tabela, instrução múltipla
TR - gatilho

U - tabela do usuário
K - restrição, chave primária (ou restrição única)
F - restrição, chave estrangeira
C - restrição, verificação
D - restrição, padrão
I - índice

Consulte os Manuais Online para obter mais informações sobre os diferentes tipos de objetos em um banco de dados SQL Server.

Este exemplo lista os objetos de estrutura do banco de dados Northwind:

USE Northwind EXECUTE sp_ListObjects NULL, NULL, 1

Este exemplo lista as visualizações e procedimentos armazenados do banco de dados Northwind:

USE Northwind EXECUTE sp_ListObjects 'V | P'

Espero que você considere útil este procedimento armazenado do sistema.*/

USE master
GO
CREATE PROCEDURE dbo.sp_ListObjects
    @DBIntra varchar(100) = NULL,
    @DBExtra varchar(100) = NULL,
    @DBUltra bit = 0
AS

SET NOCOUNT ON

DECLARE @Return int
DECLARE @Retain int
DECLARE @Status int

SET @Status = 0

DECLARE @TPre varchar(10)

DECLARE @TDo3 tinyint
DECLARE @TDo4 tinyint

SET @TPre = ''

SET @TDo3 = LEN(@TPre)
SET @TDo4 = LEN(@TPre) + 1

DECLARE @icrdate datetime

DECLARE @itype char(2)

SET @itype = 'I'

IF @DBIntra IS NULL AND @DBExtra IS NULL

    BEGIN

    IF @DBUltra = 0 SET @DBIntra = 'V|P|FN|IF|TF|TR'

    ELSE            SET @DBIntra = 'U|K|F|C|D|' + RTRIM(@itype)

    END

   SELECT        O.type     AS Type
        , ISNULL(T.name,'') AS Parent
        ,        O.name     AS Object
        , ISNULL(CONVERT(varchar(30),O.crdate,120),'') AS Creation
     FROM sysobjects AS O
LEFT JOIN sysobjects AS T
       ON O.parent_obj = T.id
    WHERE ISNULL(OBJECTPROPERTY(O.id,'IsMSShipped'),1) = 0
      AND O.name NOT LIKE '%dtproper%'
      AND O.name NOT LIKE 'dt[_]%'
      AND (@DBIntra IS NULL OR CHARINDEX('|'+RTRIM(O.type)+'|','|'+(@DBIntra)+'|') > 0)
      AND (@DBExtra IS NULL OR CHARINDEX('|'+RTRIM(O.type)+'|','|'+(@DBExtra)+'|') = 0)

    UNION ALL

   SELECT        @itype     AS Type
        , ISNULL(O.name,'') AS Parent
        ,        I.name     AS Object
        , ISNULL(CONVERT(varchar(30),@icrdate,120),'') AS Creation
     FROM sysobjects AS O
     JOIN sysindexes AS I
       ON O.id = I.id
    WHERE ISNULL(OBJECTPROPERTY(O.id,'IsMSShipped'),1) = 0
      AND RTRIM(O.type) = 'U'
      AND LEFT(O.name,@TDo3) = @TPre
      AND O.name NOT LIKE '%dtproper%'
      AND O.name NOT LIKE 'dt[_]%'
      AND I.indid BETWEEN 1 AND 254
      AND LEFT(I.name,8) <> '_WA_Sys_'
      AND (@DBIntra IS NULL OR CHARINDEX('|'+RTRIM(@itype)+'|','|'+(@DBIntra)+'|') > 0)
      AND (@DBExtra IS NULL OR CHARINDEX('|'+RTRIM(@itype)+'|','|'+(@DBExtra)+'|') = 0)

 ORDER BY Type, Parent, Object

SET @Retain = @@ERROR IF @Status = 0 SET @Status = @Retain

SET NOCOUNT OFF

RETURN (@Status)

GO