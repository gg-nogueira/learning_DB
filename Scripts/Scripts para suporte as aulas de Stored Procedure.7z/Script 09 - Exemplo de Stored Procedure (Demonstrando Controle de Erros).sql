-- FMU - Faculdades Metropolitanas Unidas
-- Curso	:CST em Análise e Desenvolvimento de Sistemas
-- Objetivo	:Exemplo de transação através do SQL (DTL - Linguagem de Transação de Dados)
-- Data: Segundo Semestre 2019
-- Verificando retorno de erro de uma operação de divisão por zero

-- Se existir DROPAR, caso contrário CRIAR a Stored Procedure
   IF OBJECT_ID ( 'grp01.uSP_ShowErros', 'P' ) IS NOT NULL
		DROP PROCEDURE grp01.uSP_ShowErros;
   GO
		CREATE PROCEDURE grp01.uSP_ShowErros (@SPdivisor int, @SPDividendo int OUTPUT)
 AS
	BEGIN TRY 
		-- Todo grupo de instruções SQL que estiverem entre BEGIN TRY e END TRY sera verificado
		-- No caso de qualquer erro, principalmento aqueles com severidade maior ou igual a 10
		-- Exemplos: Integridade referencial, falhas de software / hardware o bloco
		-- Passa o erro para o grupo CATCH. Este por sua vez verifica o tipo de erro e faz o adequado
		-- tratamento: executando um commit ou rollback.
		-- ************************************************
		-- Forçando uma geração de erro na divisão por ZERO.  
		-- Declaração de variável
		declare @divisor int;
		declare @dividendo int;
		-- Atribuição de variáveis
		-- SET @divisor = 100;
		-- SET @dividendo = 0;
		-- Divisão
		SELECT @dividendo/@divisor; 
		
	END TRY  
	BEGIN CATCH  
		 SELECT  ERROR_NUMBER()		AS ErrorNumber  
				,ERROR_SEVERITY()	AS ErrorSeverity  
				,ERROR_STATE()		AS ErrorState  
				,ERROR_PROCEDURE()	AS ErrorProcedure  
				,ERROR_LINE()		AS ErrorLine  
				,ERROR_MESSAGE()	AS ErrorMessage; -- Execute error retrieval routine.  
				SELECT ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
;
		DECLARE @vDivisor   int
		DECLARE @vDividendo int
		SET @vDivisor = 100
		SET @vDividendo = 0

EXEC grp01.uSP_ShowErros @vDivisor, @vDividendo  OUTPUT PRINT @vDivisor/ @vDividendo 