-- IES          : FMU - Faculdades Metropolinas Unidas
-- Cursos		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de Dados I
-- Objetivo		: Exemplificar a criação de Stored Procedure
--
-- Testar de a Stored Procedure ja existe
-- Se existir DROPAR, caso contrário CRIAR a Stored Procedure
   IF OBJECT_ID ( 'grp01.uSP_ShowDiscNota', 'P' ) IS NOT NULL
		DROP PROCEDURE grp01.uSP_ShowDiscNota;
   GO
		CREATE PROCEDURE grp01.uSP_ShowDiscNota
-- Definição dos parametros de entrada
			(@cddisciplina char(03),
			 @sem    		smallint,
			 @mediaFinal decimal OUTPUT)
		AS	
			SELECT @mediaFinal= AVG((((B.notaavcont*30 + B.notaprvreg*70)/100)))
			FROM grp01.BOLETIM B
			WHERE B.coddisciplina=@cddisciplina AND B.semeste = @sem
	
/* Paramêtros para execução da Stored Procedure 
	DECLARE @mediafinal 	decimal
	DECLARE @coddisciplina  char(03)
	DECLARE @sem    		smallint
	SET @cddisciplina = '572'
	SET @sem = 1

	EXEC grp01.uSP_ShowDiscNota @cddisciplina, @sem, @mediaFinal OUTPUT PRINT @mediaFinal 
*/