CREATE PROCEDURE grp01.usp_SearchProducts2  
(
	  @ProductID			NVARCHAR(50) = NULL	
	 ,@Name					NVARCHAR(100) = NULL	
	 ,@ProductNumber        NVARCHAR(100) = NULL	
	 ,@Color				NVARCHAR(100) = NULL	
	 
	
)
AS          
BEGIN      
	SET NOCOUNT ON;  
 
	DECLARE @SQL							NVARCHAR(MAX)
	DECLARE @ParameterDef					NVARCHAR(500)
 
    SET @ParameterDef =      '@ProductID			NVARCHAR(50),
							@Name					NVARCHAR(100),
							@ProductNumber			NVARCHAR(100),
							@Color					NVARCHAR(100)'
 
 
 
    SET @SQL = 'SELECT ProductID
						,Name
						,ProductNumber
						,Color
						,StandardCost
						,Size
						,Weight
					FROM SalesLT.Product WHERE -1=-1 ' 
 
IF @ProductID IS NOT NULL AND @ProductID <> 0 
SET @SQL = @SQL+ ' AND ProductID = @ProductID'
 
IF @Name IS NOT NULL AND @Name <> ''
 
SET @SQL = @SQL+ ' AND Name like ''%'' + @Name + ''%'''
 
 
IF @ProductNumber IS NOT NULL AND @ProductNumber <>''
SET @SQL = @SQL+ ' AND ProductNumber like ''%'' + @ProductNumber + ''%'''
 
IF @Color IS NOT NULL AND @Color <>''
SET @SQL = @SQL+  ' AND Color like ''%'' + @Color + ''%'''
 
   EXEC sp_Executesql     @SQL,  @ParameterDef, @ProductID=@ProductID,@Name=@Name,@ProductNumber=@ProductNumber,@Color=@Color
               
                
 
END
 
GO