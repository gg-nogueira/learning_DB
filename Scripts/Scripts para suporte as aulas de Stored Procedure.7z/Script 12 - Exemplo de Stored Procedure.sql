CREATE TABLE #temptable (
	ProductID VARCHAR(50)
	,Name VARCHAR(100)
	,ProductNumber VARCHAR(100)
	)
 
EXECUTE sp_executesql N' INSERT INTO #temptable
		  SELECT ProductID,Name,ProductNumber
          FROM SalesLT.Product where ProductID = @Pid and ProductNumber=@PNumber'
	,N'@Pid varchar(50),@PNumber varchar(50)'
	,@pid = '680'
	,@PNumber = 'FR-R92B-58';
 
SELECT *
FROM #temptable