-- FMU			: Faculdades Metropolitanas Unidas
-- Curso		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de dados I
-- Objetivo		: Exemplificar Stored Procedure
-- Data			: Prim Sem
-- 
/*				: Stored Procedure para atualização de registro / tupla na tabela BOLETIM 
				  Este é um tipo de Store Procedure definido pelo usuário e, portanto,
				  será armazenado no em um banco de dados definido pelo usuário ou em 
				  todos os bancos de dados do sistema, exceto no banco de dados RESOURCE 
*/
	DROP PROCEDURE IF EXISTS grp01.uSP_UpdateBoletim
	GO
	CREATE PROCEDURE grp01.uSP_UpdateBoletim
/* Perceba que uma SP está vinculada ao SCHEMA do banco, ogo, se não for tomado este cuidado 
   a SP será criada no SCHEMA default do SQL Server.
   Outro cuidade a ser tomado é com relação ao prefixo "Sp_". Este é o prefixo de toda Sp
   definida pelo SQL Server e que estão armazenada no Banco de Dados RESOURCE.

   Nas linha abaixo, temos os paramêtros que serão passados para a SP
*/
	(@vRa 					char(07),
	 @vNovaavcont	 		decimal(5,2),
	 @vNotaprvreg 			decimal(5,2)
	)
	
	AS
 -- Aqui começa a execução da SP
		     
    UPDATE BOLETIM SET notaavcont = @vNovaavcont*1.03, notaprvreg = @vNotaprvreg*1.05
    WHERE ra = @vRa 
	
-- Aqui a SP é finalizada
--0021052865	21052  	865	2	1.50	0.75

EXEC grp01.uSP_UpdateBoletim 0011030504, 5.0, 6.0