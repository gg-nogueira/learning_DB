-- FMU			: Faculdades Metropolitanas Unidas
-- Curso		: CST em An�lise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de dados I
-- Objetivo		: Exemplificar Stored Procedure
-- Data			: Prim Sem 
/*				: Stored Procedure para inser��o de registro / tupla de um  ALUNO 
				  Este � um tipo de Store Procedure definido pelo usu�rio e, portanto,
				  ser� armazenado no em um banco de dados "definido pelo usu�rio" ou em 
				  todos os bancos de dados do sistema, exceto no banco de dados RESOURCE
                  do SQL Server				  
*/
CREATE PROCEDURE grp01.uSP_Simples
/* Perceba que uma SP est� vinculada ao SCHEMA do banco, logo, se n�o for tomado este cuidado 
   a SP ser� criada no SCHEMA default do SQL Server (dbo).
   Outro cuidado a ser tomado � com rela��o ao prefixo "sp_". Este � o prefixo de toda SP
   definida pelo SQL Server e que est�o armazenadaS no Banco de Dados RESOURCE.
   Recomenda-se utilizar "usp_" que significa user stored procedure
   Nas linha abaixo, temos as declara��oes dos param�tros que ser�o utilizada na SP, neste exemplo
   n�o temos nenhum param�tro
*/
AS
/* Esta SP exibira apenas a mensagem abaixo */
SELECT 'Esta � a minha primeira SP'


Execute grp01.uSP_Simples