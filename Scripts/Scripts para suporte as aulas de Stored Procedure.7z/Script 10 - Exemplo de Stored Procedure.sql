CREATE PROCEDURE grp01.usp_SearchProducts
(
	  @ProductID			NVARCHAR(50) = NULL	
	 ,@Name					NVARCHAR(100) = NULL	
	 ,@ProductNumber        NVARCHAR(100) = NULL	
	 ,@Color				NVARCHAR(100) = NULL	
	 
	
)
AS          
BEGIN      
	SET NOCOUNT ON;  
 
	DECLARE @SQL							VARCHAR(MAX)
	DECLARE @ProductIDFilter				VARCHAR(MAX)
	DECLARE @NameFilter						VARCHAR(MAX)
	DECLARE @ProductNumberFilter			VARCHAR(MAX)
	DECLARE @ColorFilter					VARCHAR(MAX)
	DECLARE @all                            VARCHAR(2)   = '-1'
	
 
	SET @ProductIDFilter = CASE WHEN @ProductID IS NULL OR @ProductID = 0 
	THEN '''' + @all + ''' = ''' + @all + '''' 
	ELSE 'ProductID = ''' +  @ProductID + '''' 
	END
 
	SET @NameFilter = CASE WHEN @Name IS NULL OR @Name = ''
	THEN '''' + @all + ''' = ''' + @all + '''' 
	ELSE 'Name like ''%' + @Name + '%''' 
	END
 
	SET @ProductNumberFilter = CASE WHEN @ProductNumber IS NULL OR @ProductNumber = ''
	THEN '''' + @all + ''' = ''' + @all + '''' 
	ELSE 'ProductNumber like ''%' + @ProductNumber + '%''' 
	END
 
	SET @ColorFilter = CASE WHEN @Color IS NULL OR @Color = ''
	THEN '''' + @all + ''' = ''' + @all + '''' 
	ELSE 'Color like ''' + @Color + '''' 
	END
 
	
 
		  SET @SQL = 'SELECT ProductID
						,Name
						,ProductNumber
						,Color
						,StandardCost
						,Size
						,Weight
					FROM SalesLT.Product
			WHERE ' + @ProductIDFilter
			+ ' AND ' + @NameFilter + ''
			+ ' AND ' + @ProductNumberFilter + ''
			+ ' AND ' + @ColorFilter + ''
			
 
			PRINT (@sql)
			EXEC(@sql)
			
 
END
PRINT (@sql)