-- FMU			: Faculdades Metropolitanas Unidas
-- Curso		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de dados I
-- Objetivo		: Exemplificar Stored Procedure
-- Data			: Prim Sem 
/*				: Stored Procedure para inserção de registro / tupla de um  ALUNO 
				  Este é um tipo de Store Procedure definido pelo usuário e, portanto,
				  será armazenado no em um banco de dados definido pelo usuário ou em 
				  todos os bancos de dados do sistema, exceto no banco de dados RESOURCE 
*/
CREATE PROCEDURE grp01.uSP_ExibirAllalunos04
/* Perceba que uma SP está vinculada ao SCHEMA do banco, logo, se não for tomado este cuidado 
   a SP será criada no SCHEMA default do SQL Server, isto é, dbo (database owner)
   Outro cuidade a ser tomado é com relação ao prefixo "Sp_". Este é o prefixo de toda Sp
   definida pelo SQL Server e que estão armazenada no Banco de Dados RESOURCE.

   Nas linha abaixo, temos as declaraçãoes dos parâmetros que serão utilizada na SP
*/
(@datanasc		date,
 @sexo		    smallint)
AS
BEGIN -- Inicio da execução da SP

SELECT * FROM grp01.ALUNO WHERE datanasc> @datanasc AND sexo = @sexo 

END -- Final da Execução da SP


EXEC grp01.uSP_ExibirAllalunos04 '01/01/1980', 1