--Exemplo básico de SQL Dinâmica
--
--
DECLARE 
--
--  Declaração e atribuição de variáveis
--
    @Objeto VARCHAR(128) = 'sys.objects',   /*  Neste caso o objeto de dados definido é
                                              o sys.objects*/
    @Nome_Objeto VARCHAR(128) = 'syscerts', /* Aqui, está se definindo o nome do objeto desejado*/
    @Query VARCHAR(MAX)

-- Concatenação de Strings, criando a SQL Dinamica
--     
SET @Query = 'SELECT * FROM ' + @Objeto + ' WHERE [name] = ''' + @Nome_Objeto + ''''

-- Criada a frase SQL referente a SQL Dinâmica é então exibida
SELECT @Query

-- Na linha 20 utiliza-se a função EXEC, utilizando como parametro a variável @Query
EXEC(@Query)