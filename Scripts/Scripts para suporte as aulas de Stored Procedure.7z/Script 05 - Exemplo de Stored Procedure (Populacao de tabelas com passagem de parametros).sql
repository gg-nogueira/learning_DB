-- FMU			: Faculdades Metropolitanas Unidas
-- Curso		: CST em Análise e Desenvolvimento de Sistemas
-- Disciplina	: Banco de dados I
-- Objetivo		: Exemplificar Stored Procedure
-- Data			: Prim Sem
-- 
/*				: Stored Procedure para inserção de registro / tupla de um  ALUNO 
				  Este é um tipo de Store Procedure definido pelo usuário e, portanto,
				  será armazenado no em um banco de dados definido pelo usuário ou em 
				  todos os bancos de dados do sistema, exceto no banco de dados RESOURCE 
*/
	DROP PROCEDURE IF EXISTS grp01.uSP_InsertMatricula
	GO
	CREATE PROCEDURE grp01.uSP_InsertMatricula
/* Perceba que uma SP está vinculada ao SCHEMA do banco, ogo, se não for tomado este cuidado 
   a SP será criada no SCHEMA default do SQL Server.
   Outro cuidade a ser tomado é com relação ao prefixo "Sp_". Este é o prefixo de toda Sp
   definida pelo SQL Server e que estão armazenada no Banco de Dados RESOURCE.

   Nas linha abaixo, temos os paramêtros que serão passados para a SP
*/
	(@vRa 				char(07),
	 @vCdcurso	 		char(03),
	 @vTurma 			char(07),
	 @vDatamatricula	date)
	
	AS
 -- Aqui começa a execução da SP
		INSERT INTO grp01.MATRICULA (ra, codcurso, turma, datamatricula)
		VALUES(@vRa, @vCdcurso, @vTurma, @vDatamatricula)
-- Aqui a SP é finalizada
SET LANGUAGE ENGLISH

DECLARE  @spRa 				char(07)
DECLARE	 @spCdcurso	 		char(03)
DECLARE	 @spTurma 			char(07)
DECLARE	 @spDatamatricula	date

SET @spRa = '813998'
SET @spCdcurso = '126'
SET @spTurma = 'TGFN2A'
SET @spDatamatricula='2013/04/20'

EXEC grp01.uSP_InsertMatricula @spRa,@spCdcurso,@spTurma,@spDatamatricula   