

--------------------------------------------------------------------

Stored Procedure: sp_AnalyzeColumn

--------------------------------------------------------------------



USE master
GO
CREATE PROCEDURE dbo.sp_AnalyzeColumn
    @DBFetch varchar(4000),
    @DBField varchar(100)
AS

SET NOCOUNT ON

DECLARE @Return int
DECLARE @Retain int
DECLARE @Status int

SET @Status = 0

DECLARE @TPre varchar(10)

DECLARE @TDo3 tinyint
DECLARE @TDo4 tinyint

SET @TPre = ''

SET @TDo3 = LEN(@TPre)
SET @TDo4 = LEN(@TPre) + 1

DECLARE @Task varchar(8000)

DECLARE @Bank varchar(4000)

DECLARE @Wish varchar(100)

SET @Bank = @TPre + @DBFetch

IF NOT EXISTS (SELECT * FROM sysobjects WHERE RTRIM(type) = 'U' AND name = @Bank)

    BEGIN

    SET @Bank = CASE WHEN LEFT(@DBFetch,6) = 'SELECT' THEN '(' + @DBFetch + ')' ELSE @DBFetch END
    SET @Bank = REPLACE(@Bank,         CHAR(94),CHAR(39))
    SET @Bank = REPLACE(@Bank,CHAR(45)+CHAR(45),CHAR(32))
    SET @Bank = REPLACE(@Bank,CHAR(47)+CHAR(42),CHAR(32))

    END

SET @Wish = REPLACE(@DBField,CHAR(32),CHAR(95))

SET @Task = '   SELECT T.' + @Wish + ' AS [Value], COUNT(*) AS [Records],'

          + ' CONVERT(decimal(5,2),(COUNT(*)*100.00)/CONVERT(decimal(12,2),MAX(Z.Rows))) AS [Percent]'

          + '     FROM ' + @Bank + ' AS T, (SELECT COUNT(*) AS Rows FROM ' + @Bank + ' AS I) AS Z'

          + ' GROUP BY T.' + @Wish

          + ' ORDER BY [Records] DESC, [Value]'

IF @Status = 0 EXECUTE (@Task) SET @Return = @@ERROR

IF @Status = 0 SET @Status = @Return

SET NOCOUNT OFF

RETURN (@Status)

GO